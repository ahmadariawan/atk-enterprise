@extends('global_template.layout_app')

@section('page_title')
    Pengambilan
@endsection

@section('page_css')
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_gijgo/css/gijgo.min.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    Form Edit Pengambilan
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .img-thumbnail{
            height: 200px !important;
            width: 200px !important;
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <form id="edit_barang_keluar" action="javascript:;" type="post" autocomplete="off">
                <?php date_default_timezone_set('Asia/Jakarta'); ?>
                {{ csrf_field()  }}
                <div class="form-group">
                    <label>Tanggal Permintaan</label>
                    <input type="text" class="form-control" id="tanggal" placeholder="Tanggal Permintaan" value="<?php echo $res_data->tanggal; ?>" readonly>
                </div>

                <div class="form-group">
                    <label>Barang</label>
                    <input type="text" class="form-control" id="barang-desc" placeholder="Barang" value="<?php echo $res_data->no_item.' | '.$res_data->nama_barang; ?>" readonly>
                </div>
                
                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label>ID Transaksi</label>
                        <input type="text" class="form-control" id="nomor_transaksi_desc" value="<?php echo $res_data->nomor_trx; ?>" placeholder="ID Transaksi" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Departemen</label>
                        <input type="text" id="departemen_desc" class="form-control" value="<?php echo $res_data->nama_departemen; ?>" readonly>
                    </div>    
                </div>    

                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label>Jumlah Permintaan</label>
                        <input type="text" class="form-control" id="stok_keluar" name="stok_keluar" value="<?php echo $res_data->stok_keluar; ?>" placeholder="Jumlah Permintaan">
                    </div>    
                    <div class="col-md-6 mb-3">
                        <label>Satuan</label>
                        <input type="text" id="satuan_desc" class="form-control" value="<?php echo $res_data->satuan_barang; ?>" readonly>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Keterangan</label>
                    <textarea id="keterengan" name="keterengan" class="form-control"><?php echo $res_data->keterengan; ?></textarea>
                </div>

                <button type="button" id="back-to-list" class="btn btn-secondary">Back To List</button>
                <button type="submit" id="btn-submit" class="btn btn-primary">Submit</button>
            </form>

        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script src="{{ asset('ecm_gijgo/js/gijgo.min.js') }}"></script>
    <script>var id_barang_keluar = "<?php echo $id_barang_keluar; ?>";</script>
    <script src="{{ asset('data_barang_keluar_js/edit.min.js?n='.time()) }}"></script>
@endsection