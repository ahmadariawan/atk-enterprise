<table>
    <thead>
    <tr>
        <th>No</th>
        <th>ID Barang</th>
        <th>Nama Barang</th>
        <th>Jumlah Permintaan</th>
        <th>Stok</th>
        <th>Jumlah Dibutuhkan</th>
    </tr>
    </thead>
    <tbody>
        <?php $no = 1; ?>
        <?php foreach($data as $dt): ?>
            <tr>
                <td>{{ $no }}</td>
                <td>{{ $dt->nomor_barang }}</td>
                <td>{{ $dt->name }}</td>
                <td>{{ $dt->jumlah_permintaan }}</td>
                <td>{{ $dt->stok }}</td>
                <td>{{ $dt->jumlah_dibutuhkan }}</td>
            </tr>
            <?php $no++; ?>
        <?php endforeach; ?>    
    </tbody>
</table>