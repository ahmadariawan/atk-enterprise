@extends('global_template.layout_app')

@section('page_title')
    Data Jenis Barang
@endsection

@section('page_css')
    <link href="{{ asset('ecm_datatables/datatables.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    List Data Jenis Barang
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .row-selected{
            background-color: rgba(0,0,0,.075);
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <table id="data-jenis-barang" class="table table-hover" style="width: 100%">
                <thead>
                <tr class="bg-primary text-white" style="border-top-left-radius: 10px;border-top-right-radius: 10px;">
                    <th width="2%" class='text-center'>#</th>
                    <th width="2%" class='text-center'>No</th>
                    <th width="10%" class='text-center'>Nama Jenis</th>
                    <th width="2%" class='text-center'>Action</th>
                </tr>
                </thead>
                <tfoot>
                <?php $data_index = 0; ?>
                <tr>
                    <td><?php $data_index++; ?></td>
                    <td><?php $data_index++; ?></td>
                    <td><input type="text" id="nama_jenis_search" class="form-control form-control-sm text-center data-jenis-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td></td>
                </tr>
                </tfoot>
            </table>

        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="Newsubmenu" tabindex="-1" role="dialog" aria-labelledby="NewsubmenuLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="NewsubmenuLabel">Tambah Data Departemen</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="add_jenis_barang" action="javascript:;" type="post">
                    {{ csrf_field()  }}
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Jenis Barang</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Nama">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambahkan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_datatables/datatables.min.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script>MODULE_FN = <?php echo json_encode($module_fn); ?></script>
    <script src="{{ asset('data_jenisbarang_js/jenis_barang_view.min.js?n='.time()) }}"></script>
@endsection