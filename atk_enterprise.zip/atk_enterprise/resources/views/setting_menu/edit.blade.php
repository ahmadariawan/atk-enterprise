@extends('global_template.layout_app')

@section('page_title')
    Setting Menu
@endsection

@section('page_css')
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_input_tags/tagsinput.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    Setting Menu {{ $res_sys_menu->name }}
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .img-thumbnail{
            height: 200px !important;
            width: 200px !important;
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <!-- <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Home</a>
                    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
                    <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a> -->
                    <?php $i = 0; ?>
                    <?php foreach($res_sys_menu_role as $val): ?>
                        <?php if($i == 0): ?>
                            <?php $class = 'nav-item nav-link active'; ?>
                        <?php else: ?>
                            <?php $class = 'nav-item nav-link'; ?>
                        <?php endif; ?>

                        <a class="<?php echo $class; ?>" id="<?php echo strtolower($val->group_name); ?>_tab" data-toggle="tab" href="#<?php echo strtolower($val->group_name); ?>" role="tab" aria-controls="<?php echo strtolower($val->group_name); ?>" aria-selected="true"><?php echo $val->group_name; ?></a>

                        <?php $i++; ?>
                    <?php endforeach; ?>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <!-- <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">...</div>
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">...</div>
                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">...</div> -->
                <?php $i = 0; ?>
                <?php foreach($res_sys_menu_role as $val): ?>
                    <?php if($i == 0): ?>
                        <?php $class = 'tab-pane fade show active'; ?>
                    <?php else: ?>
                        <?php $class = 'tab-pane fade'; ?>
                    <?php endif; ?>

                    <div class="<?php echo $class; ?>" id="<?php echo strtolower($val->group_name); ?>" role="tabpanel" aria-labelledby="<?php echo strtolower($val->group_name); ?>_tab">
                        <table class="table table-bordered" style="width: 100%">
                            <tbody>
                                <tr>
                                    <td class="col-md-2">Memiliki Akses ?</td>
                                    <td>
                                        <div class="form-group">
                                            <select class="form-control hak-akses" data-id="{{ $val->id }}">
                                                <?php $y_selected = ($val->is_akses == 1) ? 'selected="true"' : '';  ?>
                                                <?php $t_selected = ($val->is_akses == 0) ? 'selected="true"' : '';  ?>
                                                <option value="1" <?php echo $y_selected; ?>>Ya</option>
                                                <option value="0" <?php echo $t_selected; ?>>Tidak</option>
                                            </select>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="col-md-2">Fungsi Modul</td>
                                    <td>
                                        <div class="form-group">
                                            <?php $modul_fn = json_decode($val->module_fuction, true); ?>
                                            <?php $modul_fn2 = implode(',',$modul_fn); ?>
                                            <input type="text" class="form-control module_fn" data-id="{{ $val->id }}" data-role="tagsinput" value="<?php echo $modul_fn2; ?>">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="col-md-2">Tanggal Ditutup</td>
                                    <td>
                                        <div class="form-group">
                                            <?php $tgl_ditutup = json_decode($val->tanggal_ditutup, true); ?>
                                            <?php $tgl_ditutup2 = implode(',',$tgl_ditutup); ?>
                                            <input type="text" class="form-control tgl_ditutup" data-id="{{ $val->id }}" data-role="tagsinput" value="<?php echo $tgl_ditutup2; ?>">
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <?php $i++; ?>
                <?php endforeach; ?>
            </div>
             
            <button type="button" id="back-to-list" class="btn btn-secondary">Back To List</button>
        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script src="{{ asset('ecm_input_tags/tagsinput.js') }}"></script>
    <!-- <script>var id_departemen = "<?php //echo $id_departemen; ?>";</script> -->
    <script src="{{ asset('setting_menu_js/edit.min.js?n='.time()) }}"></script>
@endsection