@extends('global_template.layout_app')

@section('page_title')
    Edit Data Dosen
@endsection

@section('page_css')
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    Form Edit Data Dosen
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .img-thumbnail{
            height: 200px !important;
            width: 200px !important;
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <img src="{{ asset('uploads/'.$res_data->foto_path) }}" alt="..." class="img-thumbnail">

            <div style="margin-bottom: 20px"></div>

            <form id="edit_dosen" action="javascript:;" type="post" enctype="multipart/form-data">
                {{ csrf_field()  }}
                <div class="form-group">
                    <label>NIDN Dosen</label>
                    <input type="text" class="form-control" id="nidn" value="{{ $res_data->nidn }}" readonly>
                </div>
                <div class="form-group">
                    <label>Nama Dosen</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Nama" value="{{ $res_data->name }}">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Alamat" value="{{ $res_data->email }}">
                </div>
                <div class="form-group">
                    <label>Upload Foto Jika Ingin Merubah Foto</label>
                    <input type="file" class="form-control" id="up_file" name="up_file">
                </div>

                <button type="button" id="back-to-list" class="btn btn-secondary">Back To List</button>
                <button type="submit" id="btn-submit" class="btn btn-primary">Submit</button>
            </form>

        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script>var id_dosen = "<?php echo $id_dosen; ?>";</script>
    <script src="{{ asset('data_dosen_js/data_dosen_edit.min.js?n='.time()) }}"></script>
@endsection