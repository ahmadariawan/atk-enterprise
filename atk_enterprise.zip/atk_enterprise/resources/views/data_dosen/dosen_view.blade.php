@extends('global_template.layout_app')

@section('page_title')
    Data Dosen
@endsection

@section('page_css')
    <link href="{{ asset('ecm_datatables/datatables.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    List Data Dosen
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .row-selected{
            background-color: rgba(0,0,0,.075);
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <table id="data-pelanggan" class="table table-hover" style="width: 100%">
                <thead>
                <tr class="bg-primary text-white" style="border-top-left-radius: 10px;border-top-right-radius: 10px;">
                    <th width="2%" class='text-center' style="border-top-left-radius: 20px;">#</th>
                    <th width="2%" class='text-center'>No</th>
                    <th width="10%" class='text-center'>Nidn</th>
                    <th width="20%" class='text-center'>Nama Dosen</th>
                    <th width="20%" class='text-center'>Email</th>
                    <th width="2%" class='text-center' style="border-top-right-radius: 10px;">Action</th>
                </tr>
                </thead>
                <tfoot>
                <?php $data_index = 0; ?>
                <tr>
                    <td><?php $data_index++; ?></td>
                    <td><?php $data_index++; ?></td>
                    <td><input type="text" id="nidn_search" class="form-control form-control-sm text-center data-pelanggan-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_dosen_search" class="form-control form-control-sm text-center data-pelanggan-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="email_search" class="form-control form-control-sm text-center data-pelanggan-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td></td>
                </tr>
                </tfoot>
            </table>

        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="Newsubmenu" tabindex="-1" role="dialog" aria-labelledby="NewsubmenuLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="NewsubmenuLabel">Tambah Data Dosen</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="add_dosen" action="javascript:;" type="post" enctype="multipart/form-data">
                    {{ csrf_field()  }}
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Dosen</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Nama">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="email">
                        </div>
                        <div class="form-group">
                            <label>Upload Foto</label>
                            <input type="file" class="form-control" id="up_file" name="up_file">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Tambahkan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_datatables/datatables.min.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script src="{{ asset('data_dosen_js/data_dosen.min.js?n='.time()) }}"></script>
@endsection