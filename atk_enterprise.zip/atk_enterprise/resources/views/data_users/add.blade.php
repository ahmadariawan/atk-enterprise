@extends('global_template.layout_app')

@section('page_title')
    Users
@endsection

@section('page_css')
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_gijgo/css/gijgo.min.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    Form Tambah User
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .img-thumbnail{
            height: 200px !important;
            width: 200px !important;
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <form id="add_user" action="javascript:;" type="post" autocomplete="off">
                {{ csrf_field()  }}
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Username">
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="text" class="form-control" id="password" name="password" placeholder="Password">
                </div>

                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Nama">
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Email">
                </div>

                <div class="form-group">
                    <label>No.Telpon</label>
                    <input type="text" class="form-control" id="no_telp" name="no_telp" placeholder="No.Telpon">
                </div>

                <div class="form-group">
                    <label>Departemen</label>
                    <select class="form-control" id="departemen_id" name="departemen_id">
                        <option value="">Pilih Satu</option>
                        <?php foreach($res_departemen as $dt): ?>
                            <option value="{{ $dt->id }}">{{ $dt->name }}</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Group</label>
                    <select class="form-control" id="sys_group_child_id" name="sys_group_child_id">
                        <option value="">Pilih Satu</option>
                        <?php foreach($res_group as $dt): ?>
                            <option value="{{ $dt->id }}">{{ $dt->name }}</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="button" id="back-to-list" class="btn btn-secondary">Back To List</button>
                <button type="submit" id="btn-submit" class="btn btn-primary">Submit</button>
            </form>

        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script src="{{ asset('ecm_gijgo/js/gijgo.min.js') }}"></script>
    <!-- <script>var id_satuan_barang = "<?php //echo $id_satuan_barang; ?>";</script> -->
    <script src="{{ asset('data_users_js/add.min.js?n='.time()) }}"></script>
@endsection