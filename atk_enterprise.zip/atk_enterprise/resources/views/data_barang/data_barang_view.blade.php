@extends('global_template.layout_app')

@section('page_title')
    Data Barang
@endsection

@section('page_css')
    <link href="{{ asset('ecm_datatables/datatables.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    List Data Barang
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .row-selected{
            background-color: rgba(0,0,0,.075);
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <table id="data-barang" class="table table-hover" style="width: 100%">
                <thead>
                <tr class="bg-primary text-white" style="border-top-left-radius: 10px;border-top-right-radius: 10px;">
                    <th width="2%" class='text-center'>#</th>
                    <th width="2%" class='text-center'>No</th>
                    <th width="10%" class='text-center'>ID Barang</th>
                    <th width="10%" class='text-center'>Nama Barang</th>
                    <th width="10%" class='text-center'>Jenis Barang</th>
                    <th width="2%" class='text-center'>Stok</th>
                    <th width="2%" class='text-center'>Satuan</th>
                    <th width="2%" class='text-center'>Limit Stok</th>
                    <th width="2%" class='text-center'>Action</th>
                </tr>
                </thead>
                <tfoot>
                <?php $data_index = 0; ?>
                <tr>
                    <td><input type="hidden" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="hidden" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_satuan_search" class="form-control form-control-sm text-center data-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_satuan_search" class="form-control form-control-sm text-center data-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_satuan_search" class="form-control form-control-sm text-center data-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_satuan_search" class="form-control form-control-sm text-center data-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_satuan_search" class="form-control form-control-sm text-center data-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td><input type="text" id="nama_satuan_search" class="form-control form-control-sm text-center data-barang-tfoot-input-search" placeholder="search" data-index="<?php echo $data_index; $data_index++; ?>"></td>
                    <td></td>
                </tr>
                </tfoot>
            </table>

        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_datatables/datatables.min.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script>MODULE_FN = <?php echo json_encode($module_fn); ?></script>
    <script src="{{ asset('data_barang_js/data_barang_view.min.js?n='.time()) }}"></script>
@endsection