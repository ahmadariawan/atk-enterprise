@extends('global_template.layout_app')

@section('page_title')
    Tambah Data Barang
@endsection

@section('page_css')
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    Form Tambah Data Barang
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .img-thumbnail{
            height: 200px !important;
            width: 200px !important;
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <form id="add_barang" action="javascript:;" type="post">
                {{ csrf_field()  }}
                <div class="form-group">
                    <label>ID Barang</label>
                    <input type="text" class="form-control" id="nomor_barang" name="nomor_barang" placeholder="ID Barang">
                </div>

                <div class="form-group">
                    <label>Nama Barang</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Nama Barang">
                </div>

                <div class="form-group">
                    <label>Jenis Barang</label>
                    <select class="form-control" id="jenis_barang_id" name="jenis_barang_id">
                        <?php foreach($jenis_barang as $dt): ?>
                            <option value="{{ $dt->id }}">{{ $dt->name }}</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Satuan Barang</label>
                    <select class="form-control" id="satuan_barang_id" name="satuan_barang_id">
                        <?php foreach($satuan_barang as $dt): ?>
                            <option value="{{ $dt->id }}">{{ $dt->name }}</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Limit Stok</label>
                    <input type="text" class="form-control" id="limit_stok" name="limit_stok" placeholder="Limit Stok">
                </div>

                <button type="button" id="back-to-list" class="btn btn-secondary">Back To List</button>
                <button type="submit" id="btn-submit" class="btn btn-primary">Submit</button>
            </form>

        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <!-- <script>var id_satuan_barang = "<?php //echo $id_satuan_barang; ?>";</script> -->
    <script src="{{ asset('data_barang_js/data_barang_add.min.js?n='.time()) }}"></script>
@endsection