@extends('global_template.layout_app')

@section('page_title')
    Penambahan
@endsection

@section('page_css')
    <link href="{{ asset('ecm_toastr_js/toastr.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_select2/select2-bootstrap.css') }}" rel="stylesheet">
    <link href="{{ asset('ecm_gijgo/css/gijgo.min.css') }}" rel="stylesheet">
@endsection

@section('content_title')
    Form Edit Penambahan
@endsection

@section('content_data')

    <style>
        .ellipsis {
            /*margin-right: 5px;*/
            display: none;
        }

        .current {
            background-color: turquoise;
        }

        .invalid {
            border: 1px solid red;
        }

        .img-thumbnail{
            height: 200px !important;
            width: 200px !important;
        }
    </style>

    <div class="card">
        <div class="card-header">
        </div>
        <div class="card-body">

            <form id="edit_barang_masuk" action="javascript:;" type="post" autocomplete="off">
                {{ csrf_field()  }}
                <div class="form-group">
                    <label>Tanggal Masuk</label>
                    <input type="text" class="form-control date" id="tgl_masuk" name="tgl_masuk" placeholder="Tanggal Masuk" value="{{ $res_data->tgl_masuk }}">
                </div>

                <div class="form-group">
                    <label>Barang</label>
                    <input type="text" class="form-control" id="barang_desc" placeholder="Barang" value="<?php echo $list_barang->nomor_barang." | ".$list_barang->name; ?>" readonly>
                    <input type="hidden" id="barang_id" name="barang_id" value="{{ $res_data->barang_id }}">
                </div>
                    
                <div class="form-group">
                    <label>Jumlah Masuk</label>
                    <input type="text" class="form-control" id="stok_masuk" name="stok_masuk" placeholder="Jumlah Masuk" value="{{ $res_data->stok_masuk }}">
                </div>

                <div class="form-row">
                    <div class="col-md-6 mb-3">
                        <label>Stok</label>
                        <input type="text" class="form-control" id="stok" placeholder="Stok" value="{{ $stok }}" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Satuan</label>
                        <input type="text" class="form-control" id="stok_desc" placeholder="Satuan" value="{{ $list_barang->satuan_barang }}" readonly>
                    </div>    
                </div>

                <!-- <div class="form-group">
                    <label>Total Stok</label>
                    <input type="text" class="form-control" id="tot_stok" placeholder="Total Stok" readonly>
                </div> -->
                
                <button type="button" id="back-to-list" class="btn btn-secondary">Back To List</button>
                <button type="submit" id="btn-submit" class="btn btn-primary">Submit</button>
            </form>

        </div>
    </div>
@endsection

@section('page_js')
    <script src="{{ asset('ecm_toastr_js/toastr.js') }}"></script>
    <script src="{{ asset('ecm_select2/select2.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/jquery.validate.js') }}"></script>
    <script src="{{ asset('ecm_jquery_validation/additional-methods.js') }}"></script>
    <script src="{{ asset('ecm_gijgo/js/gijgo.min.js') }}"></script>
    <script>var id_barang_masuk = "<?php echo $id_barang_masuk; ?>";</script>
    <script src="{{ asset('data_barang_masuk_js/edit.min.js?n='.time()) }}"></script>
@endsection