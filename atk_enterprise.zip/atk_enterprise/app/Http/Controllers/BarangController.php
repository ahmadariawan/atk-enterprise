<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use SysMenuSetting;
use GetStok;

class BarangController extends Controller
{
    //
    private function role_setting($menu_id)
    {
        return SysMenuSetting::sys_menu_setting($menu_id);
    }

    private function role_setting_modul_fn($menu_id)
    {
        $role_setting = SysMenuSetting::sys_menu_setting($menu_id);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    #DATA BARANG FUNCTION START
    public function show()
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            return view('data_barang.data_barang_view',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list()
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $nomor_barang_search = $_REQUEST['columns'][2]['search']['value'];
            $nama_barang_search = $_REQUEST['columns'][3]['search']['value'];
            $jenis_barang_search = $_REQUEST['columns'][4]['search']['value'];
            $stok_barang_search = $_REQUEST['columns'][5]['search']['value'];
            $satuan_barang_search = $_REQUEST['columns'][6]['search']['value'];
            $limitstok_barang_search = $_REQUEST['columns'][7]['search']['value'];
    
            $where = [];
            $where[] = ['a.is_deleted', '=', 0];
            if(!empty($nomor_barang_search)){
                $where[] = ['a.nomor_barang', '=', $nomor_barang_search];
            }
    
            if(!empty($nama_barang_search)){
                $where[] = ['a.name', '=', $nama_barang_search];
            }
    
            if(!empty($jenis_barang_search)){
                $where[] = ['b.name', '=', $jenis_barang_search];
            }
    
            //!empty($stok_barang_search)
            if($stok_barang_search !== ""){
                $where[] = ['a.stok', '=', $stok_barang_search];
            }
    
            if(!empty($satuan_barang_search)){
                $where[] = ['c.name', '=', $satuan_barang_search];
            }
    
            if(!empty($limitstok_barang_search)){
                $where[] = ['a.limit_stok', '=', $limitstok_barang_search];
            }
    
            $query = DB::table('barang AS a')
                     ->select('a.*', 'b.name as jenis_barang', 'c.name as satuan_barang')
                     ->join('jenis_barang AS b', 'b.id', '=', 'a.jenis_barang_id')
                     ->join('satuan_barang AS c', 'c.id', '=', 'a.satuan_barang_id')   
                     ->where($where);
    
            $queryCount = DB::table('barang AS a')
                          ->selectRaw('COUNT(*) as cnt')
                          ->join('jenis_barang AS b', 'b.id', '=', 'a.jenis_barang_id')
                          ->join('satuan_barang AS c', 'c.id', '=', 'a.satuan_barang_id')
                          ->where($where);
    
            if(!empty($search)){
                $query->whereRaw("(a.nomor_barang LIKE '%{$search}%' OR a.name LIKE '%{$search}%' OR b.name LIKE '%{$search}%' OR a.stok LIKE '%{$search}%' OR c.name LIKE '%{$search}%' OR a.limit_stok LIKE '%{$search}%')");
                $queryCount->whereRaw("(a.nomor_barang LIKE '%{$search}%' OR a.name LIKE '%{$search}%' OR b.name LIKE '%{$search}%' OR a.stok LIKE '%{$search}%' OR c.name LIKE '%{$search}%' OR a.limit_stok LIKE '%{$search}%')");
            }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-barang-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['nomor_barang'] = $val->nomor_barang;
                $data['name'] = $val->name;
                $data['jenis_barang'] = $val->jenis_barang;
                $data['stok'] = $val->stok;
                $data['satuan_barang'] = $val->satuan_barang;
                $data['limit_stok'] = $val->limit_stok;
                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_data_barang',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }
    }

    public function add()
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            $data = [];
            $data['jenis_barang'] = DB::table('jenis_barang')->get();
            $data['satuan_barang'] = DB::table('satuan_barang')->get();
    
            return view('data_barang.data_barang_add',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_data_add(Request $request)
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');

            $data_insert = $request->all();
            $data_insert['created_by'] = 'Admin';
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');
            unset($data_insert['_token']);
    
            DB::table('barang')
                ->insert($data_insert);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function edit($id)
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data = [];
            $data['jenis_barang'] = DB::table('jenis_barang')->get();
            $data['satuan_barang'] = DB::table('satuan_barang')->get();
            $data['id_data_barang'] = $id;
    
            #GET INFO DATA
            $id = base64_decode($id);
            $data['res_data'] = DB::table('barang')->where('id','=', $id)->first();
            #END GET INFO DATA
    
            return view('data_barang.data_barang_edit',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_data_edit(Request $request)
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data_update = $request->all();

            date_default_timezone_set('Asia/Jakarta');
            unset($data_update['_token']);
            unset($data_update['id_data_barang']);
    
            $id = $request->get('id_data_barang');
            $id = base64_decode($id);
    
            DB::table('barang')->where('id', '=', $id)->update($data_update);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function delete_data(Request $request)
    {
        $role_setting = $this->role_setting(4);
        $module_fn = $this->role_setting_modul_fn(4);

        if($role_setting->is_akses && in_array('delete',$module_fn))
        {
            DB::table('barang')
            ->whereIn('id', $request->input('ids'))
            ->update(['is_deleted' => 1]);

            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }            
    }
    #DATA BARANG FUNCTION END


    #DATA BARANG MASUK FUNCTION START
    public function show_barang_masuk()
    {
        $role_setting = $this->role_setting(5);
        $module_fn = $this->role_setting_modul_fn(5);

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            return view('data_barang_masuk.view',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list_barang_masuk()
    {
        $role_setting = $this->role_setting(5);
        $module_fn = $this->role_setting_modul_fn(5);

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $search_2 = $_REQUEST['columns'][2]['search']['value'];
            $search_3 = $_REQUEST['columns'][3]['search']['value'];
            $search_4 = $_REQUEST['columns'][4]['search']['value'];
            $search_5 = $_REQUEST['columns'][5]['search']['value'];
            $search_6 = $_REQUEST['columns'][6]['search']['value'];
    
            $where = [];
            if(!empty($search_2)){
                $where[] = ['a.tgl_masuk', '=', $search_2];
            }

            if(!empty($search_3)){
                $where[] = ['b.name', '=', $search_3];
            }

            if($search_4 !== ""){
                $where[] = ['a.stok_masuk', '=', $search_4];
            }

            if($search_5 !== ""){
                $where[] = ['b.stok', '=', $search_5];
            }

            if(!empty($search_6)){
                $where[] = ['a.created_by', '=', $search_6];
            }
    
            $query = DB::table('barang_masuk AS a')
                     ->select('a.*', 'b.name as nama_barang', 'b.stok', 'd.name as satuan_barang')
                     ->join('barang AS b', function ($join) {
                        $join->on('b.id', '=', 'a.barang_id')
                             ->where('b.is_deleted', '=', 0);
                     })
                     ->join('jenis_barang AS c', 'c.id', '=', 'b.jenis_barang_id')
                     ->join('satuan_barang AS d', 'd.id', '=', 'b.satuan_barang_id')   
                     ->where($where);
    
            $queryCount = DB::table('barang_masuk AS a')
                          ->selectRaw('COUNT(*) as cnt')
                          ->join('barang AS b', function ($join) {
                            $join->on('b.id', '=', 'a.barang_id')
                                 ->where('b.is_deleted', '=', 0);
                          })
                          ->join('jenis_barang AS c', 'c.id', '=', 'b.jenis_barang_id')
                          ->join('satuan_barang AS d', 'd.id', '=', 'b.satuan_barang_id')
                          ->where($where);
    
            // if(!empty($search)){
            //     $query->whereRaw("(a.nomor_barang LIKE '%{$search}%' OR a.name LIKE '%{$search}%' OR b.name LIKE '%{$search}%' OR a.stok LIKE '%{$search}%' OR c.name LIKE '%{$search}%' OR a.limit_stok LIKE '%{$search}%')");
            //     $queryCount->whereRaw("(a.nomor_barang LIKE '%{$search}%' OR a.name LIKE '%{$search}%' OR b.name LIKE '%{$search}%' OR a.stok LIKE '%{$search}%' OR c.name LIKE '%{$search}%' OR a.limit_stok LIKE '%{$search}%')");
            // }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-barang-masuk-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['tgl_masuk'] = $val->tgl_masuk;
                $data['nama_barang'] = $val->nama_barang;
                $data['stok_masuk'] = $val->stok_masuk. " ". $val->satuan_barang;
                $data['stok'] = $val->stok;
                $data['created_by'] = $val->created_by;
                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_barang_masuk',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }
    }

    public function add_barang_masuk()
    {
        $role_setting = $this->role_setting(5);
        $module_fn = $this->role_setting_modul_fn(5);

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            $data = [];

            $where = [];
            $where[] = ['is_deleted', '=', 0];
            $data['list_barang'] = DB::table('barang')
                                   ->where($where) 
                                   ->get();
    
            return view('data_barang_masuk.add', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_stok(Request $request)
    {
        $barang_detail = DB::table('barang AS a')
                        ->select('a.*', 'b.name as jenis_barang', 'c.name as satuan_barang')
                        ->join('jenis_barang AS b', 'b.id', '=', 'a.jenis_barang_id')
                        ->join('satuan_barang AS c', 'c.id', '=', 'a.satuan_barang_id')   
                        ->where('a.id', '=', $request->get('barang_id'))
                        ->first();

        $total_stok = GetStok::get_stok($request->get('barang_id'));
        echo json_encode(array('stok' => $total_stok, 'satuan' => $barang_detail->satuan_barang));
    }

    public function save_barang_masuk_add(Request $request)
    {
        $role_setting = $this->role_setting(5);
        $module_fn = $this->role_setting_modul_fn(5);

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            $session_data = Session::all();
            date_default_timezone_set('Asia/Jakarta');

            $data_insert = $request->all();
            $data_insert['created_by'] = $session_data['username'];
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');
            unset($data_insert['_token']);
    
            DB::table('barang_masuk')
            ->insert($data_insert);
    
            #UPDATE TOTAL STOK START
            $total_stok = GetStok::get_stok($request->get('barang_id'));
            DB::table('barang')
            ->where('id', '=', $request->get('barang_id'))
            ->update(['stok' => $total_stok]);
            #UPDATE TOTAL STOK END    
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function edit_barang_masuk($id)
    {
        $role_setting = $this->role_setting(5);
        $module_fn = $this->role_setting_modul_fn(5);

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data = [];
            $data['id_barang_masuk'] = $id;
    
            #GET INFO DATA
            $id = base64_decode($id);
            $res_data = DB::table('barang_masuk')->where('id','=', $id)->first();
            $data['res_data'] = $res_data;
            #END GET INFO DATA
    
            $where = [];
            $where[] = ['a.id', '=', $res_data->barang_id];
            $where[] = ['a.is_deleted', '=', 0];
            $data['list_barang'] = DB::table('barang AS a')
                                   ->select('a.*', 'b.name as jenis_barang', 'c.name as satuan_barang')
                                   ->join('jenis_barang AS b', 'b.id', '=', 'a.jenis_barang_id')
                                   ->join('satuan_barang AS c', 'c.id', '=', 'a.satuan_barang_id')   
                                   ->where($where)
                                   ->first();
    
            #GET STOK START
            $stok_brg_masuk = DB::table('barang_masuk')
                              ->selectRaw('SUM(stok_masuk) as stok')
                              ->where('barang_id', '=', $res_data->barang_id)
                              ->first();
    
            $stok_brg_masuk2 = is_null($stok_brg_masuk->stok) ? 0 : (int)$stok_brg_masuk->stok;
           
            $stok_brg_keluar = 0;
    
            $total_stok = $stok_brg_masuk2 - $stok_brg_keluar;
    
            $data['stok'] = $total_stok;
            #GET STOK END
    
            return view('data_barang_masuk.edit',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_barang_masuk_edit(Request $request)
    {
        $role_setting = $this->role_setting(5);
        $module_fn = $this->role_setting_modul_fn(5);

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');

            $data_update = $request->all();
            $data_update['updated_by'] = 'Admin';
            $data_update['updated_datetime'] = date('Y-m-d H:i:s');
            unset($data_update['_token']);
            unset($data_update['id_barang_masuk']);
    
            $id = $request->get('id_barang_masuk');
            $id = base64_decode($id);
    
            DB::table('barang_masuk')
            ->where('id', '=', $id)
            ->update($data_update);
    
            #UPDATE TOTAL STOK START
            $total_stok = GetStok::get_stok($request->get('barang_id'));
            DB::table('barang')
            ->where('id', '=', $request->get('barang_id'))
            ->update(['stok' => $total_stok]);
            #UPDATE TOTAL STOK END    
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }
    #DATA BARANG MASUK FUNCTION END
}
