<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use App\sys_user;

class LoginPanelController extends Controller
{
    //
    public function show()
    {
        return view('login_view');
    }

    public function login_request(Request $request)
    {
        $user_name = $request->input('username');
        $password = md5($request->input('password'));

        $users = sys_user::where([
            ['username', '=', $user_name],
            ['password', '=', $password],
            ['is_active', '=', 1]
        ])->get();
        
        $users2 = $users->first();

        if($users->isEmpty())
        {
            echo json_encode(array('success' => false));
        }
        else
        {
            Session::put([
                'login' => 1,
                'sys_group_child_id' => $users2->sys_group_child_id,
                'departemen_id' => $users2->departemen_id,
                'username' => $users2->username
            ]);
    
            echo json_encode(array('success' => true));
        }

    }

    public function logout_request(Request $request)
    {
        Session::forget('login');
        Session::flush();
        Session::regenerate(true);
        Session::regenerateToken();

        return redirect()->route('panel_login_route');
    }
}
