<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SysMenuSetting;

class UsersController extends Controller
{
    //
    private function role_setting()
    {
        return SysMenuSetting::sys_menu_setting(12);
    }

    private function role_setting_modul_fn()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(12);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    public function show()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            return view('data_users.view',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $departemen_search = $_REQUEST['columns'][2]['search']['value'];
            $lokasi_search = $_REQUEST['columns'][3]['search']['value'];
    
            $where = [];
            // if(!empty($departemen_search)){
            //     $where[] = ['name', '=', $departemen_search];
            // }
    
            // if(!empty($lokasi_search)){
            //     $where[] = ['lokasi', '=', $lokasi_search];
            // }
    
            $query = DB::table('sys_user AS a')
                     ->select('a.*', 'b.name as group_name', 'c.name as dept_name')
                     ->join('sys_group_child AS b', 'b.id', '=', 'a.sys_group_child_id')
                     ->leftJoin('departemen AS c', 'c.id', '=', 'a.departemen_id')   
                     ->where($where)
                     ->whereNotIn('a.id',[1]);
    
            $queryCount = DB::table('sys_user AS a')
                          ->selectRaw('COUNT(*) as cnt')
                          ->join('sys_group_child AS b', 'b.id', '=', 'a.sys_group_child_id')
                          ->leftJoin('departemen AS c', 'c.id', '=', 'a.departemen_id')   
                          ->where($where)
                          ->whereNotIn('a.id',[1]);
    
            // if(!empty($search)){
            //     $query->whereRaw("(lokasi LIKE '%{$search}%' OR name LIKE '%{$search}%')");
            //     $queryCount->whereRaw("(lokasi LIKE '%{$search}%' OR name LIKE '%{$search}%')");
            // }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-users-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['username'] = $val->username;
                $data['name'] = is_null($val->name) ? '-' : $val->name;
                $data['email'] = is_null($val->email) ? '-' : $val->email;
                $data['no_telp'] = is_null($val->no_telp) ? '-' : $val->no_telp;
                $data['dept_name'] = is_null($val->dept_name) ? '-' : $val->dept_name;
                $data['group_name'] = $val->group_name;

                if($val->is_active)
                {
                    $icon_check = "<i class='fas fa-check'></i>";
                }
                else
                {
                    $icon_check = "<i class='fas fa-times'></i>";
                }
    
                $data['is_active'] = '<div style="text-align:center">'.$icon_check.'</div>';

                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_users',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }    
    }

    public function add()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            $data = [];
            $data['res_departemen'] = DB::table('departemen')->get();
            //DB::table('sys_group_child')->whereNotIn('id',[1])->get();
            $data['res_group'] = DB::table('sys_group_child')->get();

            return view('data_users.add', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');

            $data_insert = $request->all();
            $data_insert['created_by'] = 'Admin';
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');
            unset($data_insert['_token']);
            unset($data_insert['username']);
            unset($data_insert['password']);

            $username_name = strtolower($request->get('username'));
            $data_insert['username'] = $username_name;
            $data_insert['password'] = md5($request->get('password'));

            $res_check_username_name = DB::table('sys_user')
                                      ->where('username', '=', $username_name)
                                      ->count();
            
            if($res_check_username_name > 0)
            {
                echo json_encode(['success' => false, 'message' => 'Username sudah digunakan']);
                exit;
            }                    

            DB::table('sys_user')
            ->insert($data_insert);

            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function edit($id)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data = [];
            $data['id_user'] = $id;
            $data['res_departemen'] = DB::table('departemen')->get();
            $data['res_group'] = DB::table('sys_group_child')->whereNotIn('id',[1])->get();

            $id = base64_decode($id);
            $data['res_data'] = DB::table('sys_user')->where([ ['id', '=', $id] ])->first();

            return view('data_users.edit', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_edit_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data_update = $request->all();

            date_default_timezone_set('Asia/Jakarta');
            unset($data_update['_token']);
            unset($data_update['id_user']);
            unset($data_update['old_username']);
            unset($data_update['username']);
            unset($data_update['password']);

            $old_username = $request->get('old_username');
            $username = strtolower($request->get('username'));
            $data_update['username'] = $username;
            $data_update['password'] = md5($request->get('password'));

            $id = $request->get('id_user');
            $id = base64_decode($id);
            
            $res_check_username = DB::table('sys_user')
                                  ->where([['username', '=', $username],['username', '<>', $old_username]])
                                  ->count();
            
            if($res_check_username > 0)
            {
                echo json_encode(['success' => false, 'message' => 'Username sudah digunakan']);
                exit;
            }

            DB::table('sys_user')->where('id', '=', $id)->update($data_update);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }
}
