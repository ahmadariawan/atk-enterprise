<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use SysMenuSetting;
use GetStok;

class BarangKeluarController extends Controller
{
    //
    private function role_setting()
    {
        return SysMenuSetting::sys_menu_setting(6);
    }

    private function role_setting_modul_fn()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(6);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    private function role_setting_tgl_ditutup()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(6);
        $module_fn = json_decode($role_setting->tanggal_ditutup, true);

        return $module_fn;
    }

    public function show()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            return view('data_barang_keluar.view',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $session_data = Session::all();
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $search_2 = $_REQUEST['columns'][2]['search']['value'];
            $search_3 = $_REQUEST['columns'][3]['search']['value'];
            $search_4 = $_REQUEST['columns'][4]['search']['value'];
            $search_5 = $_REQUEST['columns'][5]['search']['value'];
            $search_6 = $_REQUEST['columns'][6]['search']['value'];
            $search_7 = $_REQUEST['columns'][7]['search']['value'];
            $search_8 = $_REQUEST['columns'][8]['search']['value'];
            $search_9 = $_REQUEST['columns'][9]['search']['value'];
    
            $where = [];
    
            if($session_data['sys_group_child_id'] == 2)
            {
                $where[] = ['a.departemen_id', '=', $session_data['departemen_id']];
            }
    
            if(!empty($search_2)){
                $where[] = ['e.name', '=', $search_2];
            }

            if(!empty($search_3)){
                $where[] = [DB::raw('CONCAT(a.nomor_transaksi,a.nomor_urut_trx)'), '=', $search_3];
            }

            if(!empty($search_4)){
                $where[] = ['a.tanggal', '=', $search_4];
            }

            if(!empty($search_5)){
                $where[] = ['b.nomor_barang', '=', $search_5];
            }

            if(!empty($search_6)){
                $where[] = ['b.name', '=', $search_6];
            }

            if($search_7 !== ""){
                $where[] = ['a.stok_keluar', '=', $search_7];
            }

            if($search_8 !== ""){
                $where[] = ['b.stok', '=', $search_8];
            }

            if(!empty($search_9)){
                $where[] = ['d.name', '=', $search_9];
            }
    
            $query = DB::table('barang_keluar AS a')
                     ->select('a.*', DB::raw('CONCAT(a.nomor_transaksi,a.nomor_urut_trx) as nomor_trx'), 'b.name as nama_barang', 'b.stok', 'b.nomor_barang as no_item', 'd.name as satuan_barang', 'e.name as nama_departemen')
                     ->join('barang AS b', function ($join) {
                        $join->on('b.id', '=', 'a.barang_id')
                             ->where('b.is_deleted', '=', 0);
                     })
                     ->join('jenis_barang AS c', 'c.id', '=', 'b.jenis_barang_id')
                     ->join('satuan_barang AS d', 'd.id', '=', 'b.satuan_barang_id')
                     ->join('departemen AS e', 'e.id', '=', 'a.departemen_id')   
                     ->where($where);
    
            $queryCount = DB::table('barang_keluar AS a')
                          ->selectRaw('COUNT(*) as cnt')
                          ->join('barang AS b', function ($join) {
                            $join->on('b.id', '=', 'a.barang_id')
                                 ->where('b.is_deleted', '=', 0);
                          })
                          ->join('jenis_barang AS c', 'c.id', '=', 'b.jenis_barang_id')
                          ->join('satuan_barang AS d', 'd.id', '=', 'b.satuan_barang_id')
                          ->join('departemen AS e', 'e.id', '=', 'a.departemen_id')
                          ->where($where);
    
            // if(!empty($search)){
            //     $query->whereRaw("(a.nomor_barang LIKE '%{$search}%' OR a.name LIKE '%{$search}%' OR b.name LIKE '%{$search}%' OR a.stok LIKE '%{$search}%' OR c.name LIKE '%{$search}%' OR a.limit_stok LIKE '%{$search}%')");
            //     $queryCount->whereRaw("(a.nomor_barang LIKE '%{$search}%' OR a.name LIKE '%{$search}%' OR b.name LIKE '%{$search}%' OR a.stok LIKE '%{$search}%' OR c.name LIKE '%{$search}%' OR a.limit_stok LIKE '%{$search}%')");
            // }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-barang-keluar-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['nama_departemen'] = $val->nama_departemen;
                $data['nomor_trx'] = $val->nomor_trx;
                $data['tanggal'] = $val->tanggal;
                $data['no_item'] = $val->no_item;
                $data['nama_barang'] = $val->nama_barang;
                $data['stok_keluar'] = $val->stok_keluar;
                $data['stok'] = $val->stok;
                $data['satuan_barang'] = $val->satuan_barang;
    
                if($val->is_approved)
                {
                    $icon_check = "<i class='fas fa-check'></i>";
                }
                else
                {
                    $icon_check = "<i class='fas fa-times'></i>";
                }
    
                $data['di_setujui'] = '<div style="text-align:center">'.$icon_check.'</div>';
                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_barang_keluar',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                }
                
                if(in_array('approval',$module_fn))
                {
                    if($val->is_approved == 0)
                    {
                        $data['action'] .= '<br/><a href="javascript:;" class="approval" title="Setujui" data-id="'.$val->id.'"><i class="fas fa-check"></i></a>';
                    }
                }

                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }   
    }

    public function add()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');
            $session_data = Session::all();
    
            $data = [];
            $data['departemen_id'] = $session_data['departemen_id'];
            
            $where = [];
            $where[] = ['is_deleted', '=', 0];
            $data['list_barang'] = DB::table('barang')
                                   ->where($where) 
                                   ->get();
            
            $data['res_dept'] = DB::table('departemen')
                                ->where('id', '=', $session_data['departemen_id'])
                                ->first();
                                
            #CREATE ID TRANSAKSI START
            $check_barang_keluar = DB::table('barang_keluar')->count();
            if($check_barang_keluar > 0)
            {
                $max_nomor_trx = DB::table('barang_keluar')
                                ->selectRaw('MAX(nomor_urut_trx) as nomor_urut_trx')
                                ->first();
    
                $no_urut_trx = $max_nomor_trx->nomor_urut_trx + 1;
                $id_transaksi = "GN/".date('ymd')."/00".$no_urut_trx;
            }
            else
            {
                $no_urut_trx = 1;
                $id_transaksi = "GN/".date('ymd')."/00".$no_urut_trx;
            }
    
            $data['no_urut_trx'] = $no_urut_trx;
            $data['id_transaksi'] = $id_transaksi;
            $data['id_transaksi2'] = "GN/".date('ymd')."/00";
            #CREATE ID TRANSAKSI END                   
    
            return view('data_barang_keluar.add', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_add(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();
        $tgl_ditutup = $this->role_setting_tgl_ditutup();

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            $session_data = Session::all();
            date_default_timezone_set('Asia/Jakarta');
    
            $data_insert = $request->all();
            $data_insert['created_by'] = $session_data['username'];
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');
            unset($data_insert['_token']);
            
            if(in_array(date('j'),$tgl_ditutup))
            {
                echo json_encode(['success' => false, 'message' => 'Maaf tanggal request permintaan sudah ditutup']);
                exit;
            }

            DB::table('barang_keluar')
                ->insert($data_insert);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function edit($id)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data = [];
            $data['id_barang_keluar'] = $id;

            $id = base64_decode($id);
            $query = DB::table('barang_keluar AS a')
                     ->select('a.*', DB::raw('CONCAT(a.nomor_transaksi,a.nomor_urut_trx) as nomor_trx'), 'b.name as nama_barang', 'b.stok', 'b.nomor_barang as no_item', 'd.name as satuan_barang', 'e.name as nama_departemen')
                     ->join('barang AS b', function ($join) {
                        $join->on('b.id', '=', 'a.barang_id')
                             ->where('b.is_deleted', '=', 0);
                     })
                     ->join('jenis_barang AS c', 'c.id', '=', 'b.jenis_barang_id')
                     ->join('satuan_barang AS d', 'd.id', '=', 'b.satuan_barang_id')
                     ->join('departemen AS e', 'e.id', '=', 'a.departemen_id')   
                     ->where('a.id', '=', $id)
                     ->first();

            $data['res_data'] = $query;
            
            return view('data_barang_keluar.edit',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_edit(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();
        $tgl_ditutup = $this->role_setting_tgl_ditutup();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            if(in_array(date('j'),$tgl_ditutup))
            {
                echo json_encode(['success' => false, 'message' => 'Maaf tanggal request permintaan sudah ditutup']);
                exit;
            }
            
            date_default_timezone_set('Asia/Jakarta');
            $session_data = Session::all();
            $data_update = $request->all();

            $data_update['updated_by'] = $session_data['username'];
            $data_update['updated_datetime'] = date('Y-m-d H:i:s');
            unset($data_update['_token']);
            unset($data_update['id_barang_keluar']);
    
            $id = $request->get('id_barang_keluar');
            $id = base64_decode($id);
    
            $where = [];
            $where[] = ['id','=',$id];
            $where[] = ['is_approved','=',0];
            DB::table('barang_keluar')->where($where)->update($data_update);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function approval(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('approval',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');
            $session_data = Session::all();

            $prevent_check_approve = DB::table('barang_keluar')
                                    ->where('id', '=', $request->get('id'))
                                    ->first();

            $total_stok = GetStok::get_stok($prevent_check_approve->barang_id);

            if(!is_null($prevent_check_approve->approved_by))
            {
                echo json_encode(['success' => false, 'msg' => 'Maaf tidak bisa di approve.']);
                exit;
            }
            
            if($prevent_check_approve->stok_keluar > $total_stok)
            {
                echo json_encode(['success' => false, 'msg' => 'Maaf jumlah permintaan melebihi stok yang ada.']);
                exit;
            }

            $data_update = [];
            $data_update['is_approved'] = 1;
            $data_update['approved_by'] = $session_data['username'];
            $data_update['approved_datetime'] = date('Y-m-d H:i:s');
            DB::table('barang_keluar')->where('id', '=', $request->get('id'))->update($data_update);

            #UPDATE TOTAL STOK START
            $total_stok2 = GetStok::get_stok($prevent_check_approve->barang_id);
            DB::table('barang')
            ->where('id', '=', $prevent_check_approve->barang_id)
            ->update(['stok' => $total_stok2]);
            #UPDATE TOTAL STOK END
            
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => false, 'msg' => 'Maaf tidak bisa di approve']);
        }
    }

    public function delete_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();
        $tgl_ditutup = $this->role_setting_tgl_ditutup();

        if($role_setting->is_akses && in_array('delete',$module_fn))
        {
            if(in_array(date('j'),$tgl_ditutup))
            {
                echo json_encode(['success' => false, 'msg' => 'Maaf tanggal request permintaan sudah ditutup']);
                exit;
            }

            DB::table('barang_keluar')
            ->whereIn('id', $request->input('ids'))
            ->where([ ['is_approved', '=', 0] ])
            ->delete();

            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    // private function get_stok($barang_id)
    // {
    //     $stok_brg_masuk = DB::table('barang_masuk')
    //                       ->selectRaw('SUM(stok_masuk) as stok')
    //                       ->where('barang_id', '=', $barang_id)
    //                       ->first();

    //     $stok_brg_masuk2 = is_null($stok_brg_masuk->stok) ? 0 : (int)$stok_brg_masuk->stok;

    //     $where = [];
    //     $where[] = ['barang_id', '=', $barang_id];
    //     $where[] = ['is_approved', '=', 1];
    //     $stok_brg_keluar = DB::table('barang_keluar')
    //                        ->selectRaw('SUM(stok_keluar) as stok')
    //                        ->where($where)
    //                        ->first();

    //     $stok_brg_keluar2 = is_null($stok_brg_keluar->stok) ? 0 : (int)$stok_brg_keluar->stok;                    

    //     $total_stok = $stok_brg_masuk2 - $stok_brg_keluar2;

    //     return $total_stok;
    // }
}
