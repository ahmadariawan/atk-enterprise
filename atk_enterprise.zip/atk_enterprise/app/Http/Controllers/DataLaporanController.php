<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Exports\InvoicesExport;
use SysMenuSetting;
use GetStok;
use Excel;

class DataLaporanController extends Controller
{
    //
    private function role_setting()
    {
        return SysMenuSetting::sys_menu_setting(13);
    }

    private function role_setting_modul_fn()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(13);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    public function show()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            $list_barang = DB::table('barang')
                           ->where([ ['is_deleted', '=', 0] ]) 
                           ->get();
            $data['list_barang'] = $list_barang;

            $id_barang = [];
            foreach($list_barang as $dt)
            {
                $id_barang[] = $dt->id;
            }
            $data['id_barang'] = $id_barang;                 

            return view('data_laporan.view', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $search_2 = $_REQUEST['columns'][2]['search']['value'];
            $search_3 = $_REQUEST['columns'][3]['search']['value'];
            $search_4 = $_REQUEST['columns'][4]['search']['value'];
            $search_5 = $_REQUEST['columns'][5]['search']['value'];
            $search_6 = $_REQUEST['columns'][6]['search']['value'];

            #UPDATE JUMLAH PERMINTAAN START
            foreach($_REQUEST['barang_id'] as $key => $val)
            {
                $data_update = [];
                $data_update['jumlah_permintaan'] = GetStok::get_stok_permintaan($val);
                DB::table('barang')->where('id', '=', $val)->update($data_update);
            }
            #UPDATE JUMLAH PERMINTAAN END

            #UPDATE JUMLAH DIBUTUHKAN START
            foreach($_REQUEST['barang_id'] as $key => $val)
            {
                $stok = GetStok::get_stok($val);
                $stok_permintaan = GetStok::get_stok_permintaan($val);
                if($stok_permintaan > $stok)
                {   
                    $data_update = [];
                    $data_update['jumlah_dibutuhkan'] = $stok_permintaan - $stok;
                    DB::table('barang')->where('id', '=', $val)->update($data_update);
                }
                else
                {
                    $data_update = [];
                    $data_update['jumlah_dibutuhkan'] = 0;
                    DB::table('barang')->where('id', '=', $val)->update($data_update);
                }
            }
            #UPDATE JUMLAH DIBUTUHKAN END

            $where = [];
            if(!empty($search_2)){
                $where[] = ['nomor_barang', '=', $search_2];
            }

            if(!empty($search_3)){
                $where[] = ['name', '=', $search_3];
            }

            if($search_4 !== ""){
                $where[] = ['jumlah_permintaan', '=', $search_4];
            }

            if($search_5 !== ""){
                $where[] = ['stok', '=', $search_5];
            }

            if($search_6 !== ""){
                $where[] = ['jumlah_dibutuhkan', '=', $search_6];
            }
    
            $query = DB::table('barang')->where($where)->whereIn('id',$_REQUEST['barang_id']);
            $queryCount = DB::table('barang')->selectRaw('COUNT(*) as cnt')->where($where)->whereIn('id',$_REQUEST['barang_id']);
    
            if(!empty($search)){
                $query->whereRaw("(nomor_barang LIKE '%{$search}%' OR name LIKE '%{$search}%' OR jumlah_permintaan LIKE '%{$search}%' OR stok LIKE '%{$search}%' OR jumlah_dibutuhkan LIKE '%{$search}%')");
                $queryCount->whereRaw("(nomor_barang LIKE '%{$search}%' OR name LIKE '%{$search}%' OR jumlah_permintaan LIKE '%{$search}%' OR stok LIKE '%{$search}%' OR jumlah_dibutuhkan LIKE '%{$search}%')");
            }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-laporan-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['nomor_barang'] = $val->nomor_barang;
                $data['name'] = $val->name;
                $data['jumlah_permintaan'] = $val->jumlah_permintaan;
                $data['stok'] = $val->stok;
                $data['jumlah_dibutuhkan'] = $val->jumlah_dibutuhkan;
                $data['action'] = "";

                // if(in_array('edit',$module_fn))
                // {
                //     $data['action'] .= '<a href="'.route('edit_departemen',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                // }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }    
    }

    public function export(Request $request) 
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('export_excel',$module_fn))
        {
            if($request->get('all_data') == "true")
            {
                $query = DB::table('barang')->where([ ['is_deleted', "=", 0] ])->whereIn('id',$request->get('barang_ids'))->get();
            }
            else
            {
                $query = DB::table('barang')->where([ ['is_deleted', "=", 0] ])->whereIn('id',$request->get('barang_id'))->get();
            }
    
            return Excel::download(new InvoicesExport($query), 'invoices.xlsx');
        }
    }
}
