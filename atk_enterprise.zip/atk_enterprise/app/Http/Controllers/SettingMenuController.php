<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SysMenuSetting;

class SettingMenuController extends Controller
{
    //
    private function role_setting()
    {
        return SysMenuSetting::sys_menu_setting(10);
    }

    private function role_setting_modul_fn()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(10);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    public function show()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            return view('setting_menu.view',$data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $modul_search = $_REQUEST['columns'][2]['search']['value'];
    
            $where = [];
            if(!empty($modul_search)){
                $where[] = ['name', '=', $modul_search];
            }
    
            $query = DB::table('sys_menu')->where($where)->whereNotIn('id',[9,10]);
            $queryCount = DB::table('sys_menu')->selectRaw('COUNT(*) as cnt')->where($where)->whereNotIn('id',[9,10]);
    
            if(!empty($search)){
                $query->whereRaw("(name LIKE '%{$search}%')");
                $queryCount->whereRaw("(name LIKE '%{$search}%')");
            }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-menu-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['name'] = $val->name;
                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_setting_menu',[base64_encode($val->id)]).'" class="" title="Setting"><i class="fas fa-edit"></i></a>';
                }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }    
    }

    public function edit($id)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $id = base64_decode($id);

            $data = [];
            $data['res_sys_menu'] = DB::table('sys_menu')->where('id', '=', $id)->first();
            $data['res_sys_menu_role'] = DB::table('sys_menu_role AS a')
                                         ->select('a.*', 'b.name as group_name')
                                         ->join('sys_group_child AS b', 'b.id', '=', 'a.sys_group_child_id')   
                                         ->where('a.sys_menu_id', '=', $id)
                                         ->get();
            
            return view('setting_menu.edit', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_edit(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data_update = [];
            $id = $request->get('id');
            $is_akses = $request->get('is_akses');
            $module_fn = $request->get('module_fn');
            $tgl_ditutup = $request->get('tgl_ditutup');
            $update_for = $request->get('update_for');

            if($update_for == 'is_akses')
            {
                $data_update['is_akses'] = $is_akses;
            }

            if($update_for == 'module_fn')
            {
                if(!empty($module_fn))
                {
                    $module_fn2 = explode(',',$module_fn);
                    $module_fn3 = json_encode($module_fn2);
                }
                else
                {
                    $module_fn3 = '[]';
                }

                $data_update['module_fuction'] = $module_fn3;
            }

            if($update_for == 'tgl_ditutup')
            {
                if(!empty($tgl_ditutup))
                {
                    $tgl_ditutup2 = explode(',',$tgl_ditutup);
                    $tgl_ditutup3 = json_encode($tgl_ditutup2);
                }
                else
                {
                    $tgl_ditutup3 = '[]';
                }

                $data_update['tanggal_ditutup'] = $tgl_ditutup3;
            }

            DB::table('sys_menu_role')->where('id', '=', $id)->update($data_update);

            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }
}
