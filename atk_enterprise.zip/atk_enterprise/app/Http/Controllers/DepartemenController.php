<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SysMenuSetting;

class DepartemenController extends Controller
{
    //

    private function role_setting()
    {
        return SysMenuSetting::sys_menu_setting(1);
    }

    private function role_setting_modul_fn()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(1);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    public function show()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();
        $data = [];

        if($role_setting->is_akses)
        {
            $data['module_fn'] = $module_fn;

            return view('data_departemen.departemen_view', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }

    }

    public function get_list()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $departemen_search = $_REQUEST['columns'][2]['search']['value'];
            $lokasi_search = $_REQUEST['columns'][3]['search']['value'];
    
            $where = [];
            if(!empty($departemen_search)){
                $where[] = ['name', '=', $departemen_search];
            }
    
            if(!empty($lokasi_search)){
                $where[] = ['lokasi', '=', $lokasi_search];
            }
    
            $query = DB::table('departemen')->where($where);
            $queryCount = DB::table('departemen')->selectRaw('COUNT(*) as cnt')->where($where);
    
            if(!empty($search)){
                $query->whereRaw("(lokasi LIKE '%{$search}%' OR name LIKE '%{$search}%')");
                $queryCount->whereRaw("(lokasi LIKE '%{$search}%' OR name LIKE '%{$search}%')");
            }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-departemen-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['name'] = $val->name;
                $data['lokasi'] = $val->lokasi;
                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_departemen',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }    
    }

    public function save_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');

            $data_insert = $request->all();
            $data_insert['created_by'] = 'Admin';
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');
            unset($data_insert['_token']);
    
            DB::table('departemen')
                ->insert($data_insert);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function delete_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('delete',$module_fn))
        {
            DB::table('departemen')
                    ->whereIn('id', $request->input('ids'))
                    ->delete();
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }            
    }

    public function edit_data($id)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data = [];
            $data['id_departemen'] = $id;
    
            #GET INFO DATA
            $id = base64_decode($id);
            $data['res_data'] = DB::table('departemen')->where('id','=', $id)->first();
            #END GET INFO DATA
    
            return view('data_departemen.departemen_view_edit', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
        
    }

    public function save_edit_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data_update = $request->all();

            date_default_timezone_set('Asia/Jakarta');
            unset($data_update['_token']);
            unset($data_update['id_departemen']);
    
            $id = $request->get('id_departemen');
            $id = base64_decode($id);
    
            DB::table('departemen')->where('id', '=', $id)->update($data_update);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }
}
