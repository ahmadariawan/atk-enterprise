<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SysMenuSetting;

class SatuanBarangController extends Controller
{
    //
    private function role_setting()
    {
        return SysMenuSetting::sys_menu_setting(3);
    }

    private function role_setting_modul_fn()
    {
        $role_setting = SysMenuSetting::sys_menu_setting(3);
        $module_fn = json_decode($role_setting->module_fuction, true);

        return $module_fn;
    }

    public function show()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $data = [];
            $data['module_fn'] = $module_fn;

            return view('satuan_barang.satuan_barang_view', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function get_list()
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses)
        {
            $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
            $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
            $search = $_REQUEST['search']['value'];
            $satuan_barang_search = $_REQUEST['columns'][2]['search']['value'];
    
            $where = [];
            if(!empty($satuan_barang_search)){
                $where[] = ['name', '=', $satuan_barang_search];
            }
    
            $query = DB::table('satuan_barang')->where($where);
            $queryCount = DB::table('satuan_barang')->selectRaw('COUNT(*) as cnt')->where($where);
    
            if(!empty($search)){
                $query->whereRaw("(name LIKE '%{$search}%')");
                $queryCount->whereRaw("(name LIKE '%{$search}%')");
            }
    
            $res_cnt = $queryCount->first();
            $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
            $rest_data = $query->offset($offset)->limit($limit)->get();
    
            $arr = [];
            $data = [];
            $i = $offset + 1;
            foreach ($rest_data as $key => $val){
    
                $data['cbox'] = '<input type="checkbox" class="data-satuan-barang-cbox" value="'.$val->id.'">';
                $data['rnum'] = $i;
                $data['name'] = $val->name;
                $data['action'] = "";

                if(in_array('edit',$module_fn))
                {
                    $data['action'] .= '<a href="'.route('edit_satuan_barang',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';
                }
    
                $arr[] = $data;
                $i++;
            }
    
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
            unset($arr);
        }
        else
        {
            echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": 0, "recordsFiltered": 0, "data": '.json_encode(array()).' }';
        }
    }

    public function save_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('add',$module_fn))
        {
            date_default_timezone_set('Asia/Jakarta');

            $data_insert = $request->all();
            $data_insert['created_by'] = 'Admin';
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');
            unset($data_insert['_token']);
    
            DB::table('satuan_barang')
                ->insert($data_insert);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function edit_data($id)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data = [];
            $data['id_satuan_barang'] = $id;
    
            #GET INFO DATA
            $id = base64_decode($id);
            $data['res_data'] = DB::table('satuan_barang')->where('id','=', $id)->first();
            #END GET INFO DATA
    
            return view('satuan_barang.satuan_barang_edit', $data);
        }
        else
        {
            return redirect()->route('home_route');
        }
    }

    public function save_edit_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('edit',$module_fn))
        {
            $data_update = $request->all();

            date_default_timezone_set('Asia/Jakarta');
            unset($data_update['_token']);
            unset($data_update['id_satuan_barang']);
    
            $id = $request->get('id_satuan_barang');
            $id = base64_decode($id);
    
            DB::table('satuan_barang')->where('id', '=', $id)->update($data_update);
    
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }
    }

    public function delete_data(Request $request)
    {
        $role_setting = $this->role_setting();
        $module_fn = $this->role_setting_modul_fn();

        if($role_setting->is_akses && in_array('delete',$module_fn))
        {
            DB::table('satuan_barang')
            ->whereIn('id', $request->input('ids'))
            ->delete();
            
            echo json_encode(['success' => true]);
        }
        else
        {
            echo json_encode(['success' => true]);
        }            
    }
}
