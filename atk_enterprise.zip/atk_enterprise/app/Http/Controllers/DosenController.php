<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class DosenController extends Controller
{
    //
    public function show()
    {
        return view('data_dosen.dosen_view');
    }

    public function get_list()
    {
        $offset = $_REQUEST['start'] ? $_REQUEST['start'] : 0 ;
        $limit = $_REQUEST['length'] ? $_REQUEST['length'] : 5;
        $search = $_REQUEST['search']['value'];
        $nidn_search = $_REQUEST['columns'][2]['search']['value'];

        $where = [];
        $where[] = ['is_deleted','=', '0'];
        if(!empty($nidn_search)){
            $where[] = ['nidn', '=', $nidn_search];
        }

        $query = DB::table('dosens')->where($where);
        $queryCount = DB::table('dosens')->selectRaw('COUNT(*) as cnt')->where($where);

        if(!empty($search)){
            $query->whereRaw("(nidn LIKE '%{$search}%' OR name LIKE '%{$search}%')");
            $queryCount->whereRaw("(nidn LIKE '%{$search}%' OR name LIKE '%{$search}%')");
        }

        $res_cnt = $queryCount->first();
        $cnt = isset($res_cnt->cnt) ? $res_cnt->cnt : 0;
        $rest_data = $query->offset($offset)->limit($limit)->get();

        $arr = [];
        $data = [];
        $i = $offset + 1;
        foreach ($rest_data as $key => $val){

            $data['cbox'] = '<input type="checkbox" class="data-dosen-cbox" value="'.$val->id.'">';
            $data['rnum'] = $i;
            $data['id'] = $val->id;
            $data['nidn'] = $val->nidn;
            $data['nama_dosen'] = $val->name;
            $data['email'] = $val->email;
            $data['action'] = "";
            $data['action'] .= '<a href="'.route('edit_data_dosen',[base64_encode($val->id)]).'" class="" title="Edit"><i class="fas fa-edit"></i></a>';

            $arr[] = $data;
            $i++;
        }

        echo '{ "success": true, "draw": '.$_REQUEST['draw'].', "recordsTotal": '.$cnt.', "recordsFiltered": '.$cnt.', "data": '.json_encode($arr).' }';
        unset($arr);
    }

    public function save_data(Request $request)
    {
        $data_insert = $request->all();

        $rules = [];
        $rules['name'] = 'required';
        $rules['email'] = 'required|email';
        $rules['up_file'] = 'required|mimes:jpeg,jpg,png,gif';

        $valid_data = Validator::make($request->all(),$rules);

        if($valid_data->fails()){

            echo json_encode([
                    'success' => false,
                    'message' => 'Periksa Setiap Isian Yang Ada !'
                ]);

        }else{
            date_default_timezone_set('Asia/Jakarta');
            unset($data_insert['_token']);
            unset($data_insert['up_file']);

            $file = $request->file('up_file');
            $foto_name = time().'_foto.'.$file->getClientOriginalExtension();
            $file->move('uploads',$foto_name);

            $data_insert['foto_path'] = $foto_name;
            $data_insert['cretated_by'] = 'Admin';
            $data_insert['created_datetime'] = date('Y-m-d H:i:s');

            $data_insert['nidn'] = 1001;
            $max_nidn = DB::table('dosens')->selectRaw('MAX(nidn) as nidn')->first();
            if(!empty($max_nidn->nidn)){

                $data_insert['nidn'] = intval($max_nidn->nidn) + 1;
            }

            DB::table('dosens')
                ->insert($data_insert);

            echo json_encode(['success' => true]);
        }
    }

    public function edit_data($id)
    {
        $data = [];
        $data['id_dosen'] = $id;

        #GET INFO DATA
        $id = base64_decode($id);
        $data['res_data'] = DB::table('dosens')->where('id','=', $id)->first();
        #END GET INFO DATA

        return view('data_dosen.dosen_view_edit', $data);
    }

    public function save_edit_data(Request $request)
    {
        $data_update = $request->all();

        $rules = [];
        $rules['name'] = 'required';
        $rules['email'] = 'required|email';
        $rules['up_file'] = 'mimes:jpeg,jpg,png,gif';

        $valid_data = Validator::make($request->all(),$rules);

        if($valid_data->fails()){

            echo json_encode([
                'success' => false,
                'message' => 'Periksa Setiap Isian Yang Ada !'
            ]);

        }else{
            date_default_timezone_set('Asia/Jakarta');
            unset($data_update['_token']);
            unset($data_update['up_file']);
            unset($data_update['id_dosen']);

            $id = $request->get('id_dosen');
            $id = base64_decode($id);

            if(!empty($_FILES['up_file']['name'])){
                $file = $request->file('up_file');
                $foto_name = time().'_foto.'.$file->getClientOriginalExtension();
                $file->move('uploads',$foto_name);
                $data_update['foto_path'] = $foto_name;
            }

            DB::table('dosens')->where('id', '=', $id)->update($data_update);

            echo json_encode(['success' => true]);
        }
    }
}
