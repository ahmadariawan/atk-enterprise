<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sys_user extends Model
{
    //
    protected $table = 'sys_user';
}
