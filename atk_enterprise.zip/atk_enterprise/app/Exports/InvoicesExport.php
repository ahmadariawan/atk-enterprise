<?php
namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class InvoicesExport implements FromView
{
    private $data;

    function __construct($datas)
    {
        $this->data = $datas;
    }   

    public function view(): View
    {
        return view('exports.invoices', ['data' => $this->data]);
    }
}