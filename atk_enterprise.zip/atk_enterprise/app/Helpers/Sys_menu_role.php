<?php
namespace App\Helpers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class Sys_menu_role
{
    public static function sys_menu_setting($sys_menu_id)
    {
        $session_data = Session::all();
        $query = DB::table('sys_menu_role AS a')
                 ->select('a.*')
                 ->join('sys_menu AS b', 'b.id', '=', 'a.sys_menu_id')
                 ->where('a.sys_group_child_id', '=', $session_data['sys_group_child_id'])
                 ->where('a.sys_menu_id', '=', $sys_menu_id)
                 ->first();

        return $query;        
    }
}