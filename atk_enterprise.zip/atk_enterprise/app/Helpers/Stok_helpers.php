<?php
namespace App\Helpers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class Stoks
{
    public static function get_stok($barang_id)
    {
        $stok_brg_masuk = DB::table('barang_masuk')
                          ->selectRaw('SUM(stok_masuk) as stok')
                          ->where('barang_id', '=', $barang_id)
                          ->first();

        $stok_brg_masuk2 = is_null($stok_brg_masuk->stok) ? 0 : (int)$stok_brg_masuk->stok;

        $where = [];
        $where[] = ['barang_id', '=', $barang_id];
        $where[] = ['is_approved', '=', 1];
        $stok_brg_keluar = DB::table('barang_keluar')
                           ->selectRaw('SUM(stok_keluar) as stok')
                           ->where($where)
                           ->first();

        $stok_brg_keluar2 = is_null($stok_brg_keluar->stok) ? 0 : (int)$stok_brg_keluar->stok;                    

        $total_stok = $stok_brg_masuk2 - $stok_brg_keluar2;

        return $total_stok;        
    }

    public static function get_stok_permintaan($barang_id)
    {
        $where = [];
        $where[] = ['barang_id', '=', $barang_id];
        $where[] = ['is_approved', '=', 0];
        $stok_brg_keluar = DB::table('barang_keluar')
                           ->selectRaw('SUM(stok_keluar) as stok')
                           ->where($where)
                           ->first();

        $total_stok = is_null($stok_brg_keluar->stok) ? 0 : (int)$stok_brg_keluar->stok;
        
        return $total_stok;
    }
}