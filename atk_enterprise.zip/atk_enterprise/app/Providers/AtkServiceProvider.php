<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AtkServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
        require app_path() . '/Helpers/Sys_menu_role.php';
        require app_path() . '/Helpers/Stok_helpers.php';
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
