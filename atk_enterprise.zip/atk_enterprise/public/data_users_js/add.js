var Index = function () {

    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var handleFormSubmit = function () {

        var rules = {};
        var messages = {};

        rules["username"] = { required: true };
        messages["username"] = { required: "wajid di isi !" };

        rules["password"] = { required: true };
        messages["password"] = { required: "wajid di isi !" };

        rules["sys_group_child_id"] = { required: true };
        messages["sys_group_child_id"] = { required: "wajid di isi !" };

        $("#add_user").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#add_user").submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = new FormData(form[0]);

            if($(this).valid()){
                $.ajax({
                    url: ThisUrl + '/add_user',
                    type: "post",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (responses) {
                        obj = JSON.parse(responses);

                        if(obj.success){
                            $('#btn-submit').remove();
                            toastr.success('Data berhasil di simpan', 'Success');
                            setTimeout(function () {
                                window.location.href = ThisUrl + '/users_list';
                            }, 3000);
                        }else{

                            toastr.error(obj.message, 'Form Tidak Valid !');
                        }
                    }
                });
            }
        });

    };

    var handleSelect2 = function(){
        $('#departemen_id').select2({
            placeholder: 'Departemen',
            theme: "bootstrap",
            allowClear: true
        });

        $('#sys_group_child_id').select2({
            placeholder: 'Group',
            theme: "bootstrap",
            allowClear: true
        });
    };

    var handleUserName = function(){
        $('#username').on('keyup',function(){
            var val = $(this).val();
            var valChange = val.replace(/\s+/g, '_');
            $(this).val(valChange);
        });
    };

    return{
        init : function(){
            $('#back-to-list').on('click',function () {
                window.location.href = ThisUrl + '/users_list';
            });

            handleFormSubmit();
            handleSelect2();
            handleUserName();
        }
    }
}();

$(document).ready(function(){
    Index.init();
});