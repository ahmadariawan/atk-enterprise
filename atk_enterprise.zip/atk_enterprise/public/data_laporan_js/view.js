var Index = function () {

    var aSelected = [];
    var table;
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var ajaxPrm = {};
        ajaxPrm["_token"] = CSRF_TOKEN;
        ajaxPrm["barang_id[]"] = $('#barang_id').val();

    var handleDataTable = function(){
        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-primary btn-sm mr-1';
        table = $('#data-laporan').DataTable({
            "searching": true,
            "scrollX": true,
            "paging": true,
            "lengthMenu": [[5, 10, 25, 50, 100], [5, 10, 25, 50, 100]],
            "pagingType": "simple_numbers",
            "language": {
                "info": "Menampilkan _START_ - _END_ dari _TOTAL_ data",
                "infoEmpty": "Menampilkan 0 - 0 dari 0 data",
                "infoFiltered": "",
                "zeroRecords": "Data tidak di temukan",
                "loadingRecords": "Loading...",
                "processing": "Processing...",
            },
            "columnDefs": [
                { "searchable": false, "targets": [0, 1, 4] },
                { "orderable": false, "targets": [0, 1, 4] },
            ],
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": ThisUrl + "/get_list_data_laporan",
                "type": "POST",
                "data" : function(data){
                    $.each(ajaxPrm, function(key, value) {
                        data[key] = value;
                    });
                    return data;
                }
            },
            "columns": [
                { "data": "cbox" },
                { "data": "rnum" },
                { "data": "nomor_barang" },
                { "data": "name" },
                { "data": "jumlah_permintaan" },
                { "data": "stok" },
                { "data": "jumlah_dibutuhkan" },
                { "data": "action" }
            ],
            "rowCallback": function( row, data ) {
                $(row).addClass('text-center');
                // $(row).children().eq(0).attr('style','border-left: 1px solid #e3e6f0;');
                // $(row).children().eq(5).attr('style','border-right: 1px solid #e3e6f0;');
            },
            "dom": '<"toolbar">lfrtip',
            "drawCallback": function( settings ) {

                $('.data-laporan-cbox').on('click', function () {
                    handleAddDeleteAselected($(this).val(), $(this).parents()[1]);
                });

                $('#btn-delete').attr('disabled','');
                aSelected.splice(0,aSelected.length);

            }
        });

        $("#sidebarToggle").on('click', function () {
            table.draw();
        });

        $("#data-laporan_paginate").addClass("table-responsive");

        $('#data-laporan_wrapper').attr('style','margin-top:10px;');


        $("div.toolbar").html(
            '<a href="javascript:;" id="btn-refresh" class="btn btn-secondary btn-sm mr-1 mb-3">Refresh</a>' +
            '<a href="javascript:;" id="export-excel" class="btn btn-success btn-sm mr-1 mb-3" style="visibility:hidden">Export Excel</a>'
            // '<button type="button" id="btn-delete" class="btn btn-danger btn-sm mb-3" style="visibility:hidden">Hapus Data</button>'
            // '<button type="button" id="btn-export-excel" class="btn btn-success btn-sm mb-3" style="float: right">Export Excel</button>'
        );

        $("div #data-laporan_filter").find(':input').addClass('form-control form-control-sm');

        $(".data-laporan-tfoot-input-search").on('change',function(){
            var data_index = $(this).attr('data-index');
            table.columns(data_index).search( $(this).val() ).draw();
        });

        $('#btn-refresh').on('click', function(){
            window.location.reload();
        });

        $('#btn-delete').attr('disabled','');

        if($.inArray('add',MODUL_FN) !== -1){
            $('#btn-add').css('visibility','visible');
        }

        if($.inArray('delete',MODUL_FN) !== -1){
            $('#btn-delete').css('visibility','visible');
        }

        if($.inArray('export_excel',MODUL_FN) !== -1){
            $('#export-excel').css('visibility','visible');
        }
    };

    var handleAddDeleteAselected = function (value, parentElement) {

        var check_value = $.inArray(value, aSelected);
        if(check_value !== -1){
            $(parentElement).removeClass('row-selected');
            aSelected.splice(check_value, 1);
        }else{
            $(parentElement).addClass('row-selected');
            aSelected.push(value);
        }

        handleBtnDisableEnable();
    };

    var handleBtnDisableEnable = function () {
        if(aSelected.length > 0){
            $('#btn-delete').removeAttr('disabled');
        }else{
            $('#btn-delete').attr('disabled','');
        }
    };

    var handleBarang = function(){
        $('#barang_id').select2({
            placeholder: 'Barang',
            theme: "bootstrap",
            allowClear: true,
            multiple: true
        });

        $('#barang_id').on('select2:unselect', function (e) {
            // Do something
        });

        $('#barang_id').on('select2:clear', function (e) {
            // Do something
        });
    };

    var handleFormSubmit = function(){
        var rules = {};
        var messages = {};

        rules["barang_id"] = { required: true };
        messages["barang_id"] = { required: "wajid di isi !" };

        $("#search").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#search").submit(function (e) {
            e.preventDefault();

            if($(this).valid()){
                ajaxPrm = {};
                ajaxPrm["_token"] = CSRF_TOKEN;
                ajaxPrm["barang_id"] = $('#barang_id').val();
                table.draw();
            }
        });
    };

    var handleAllBarang = function(){
        $('#all-barang').on('click', function(){
            $('#barang_id').val(null).trigger('change');
            ajaxPrm = {};
            ajaxPrm["_token"] = CSRF_TOKEN;
            ajaxPrm["barang_id"] = ID_BARANG;

            table.draw();
        });
    };

    var handleExportExcel = function(){
        $('#export-excel').on('click', function(){
            var barang_id = $('#barang_id').val();
            var all_data = false;
            if(barang_id.length){
                all_data = false;
            }else{
                all_data = true;
            }

            $('body').find('#form-export').remove();

            var form = document.createElement('form');
            form.method='POST';
            form.action= ThisUrl + '/data_laporan_export';
            form.setAttribute('id', 'form-export');

            $.each(barang_id, function(key,val){
                var hiddenField1 = document.createElement("input");
                hiddenField1.setAttribute("type", "hidden");
                hiddenField1.setAttribute("name", "barang_id[]");
                hiddenField1.setAttribute("value", val);
                form.appendChild(hiddenField1);
            });

            $.each(ID_BARANG, function(key,val){
                var hiddenField2 = document.createElement("input");
                hiddenField2.setAttribute("type", "hidden");
                hiddenField2.setAttribute("name", "barang_ids[]");
                hiddenField2.setAttribute("value", val);
                form.appendChild(hiddenField2);
            });

            var hiddenField3 = document.createElement("input");
            hiddenField3.setAttribute("type", "hidden");
            hiddenField3.setAttribute("name", "all_data");
            hiddenField3.setAttribute("value", all_data);
            form.appendChild(hiddenField3);

            var hiddenField4 = document.createElement("input");
            hiddenField4.setAttribute("type", "hidden");
            hiddenField4.setAttribute("name", "_token");
            hiddenField4.setAttribute("value", CSRF_TOKEN);
            form.appendChild(hiddenField4);    

            form.target='_blank';
            document.body.appendChild(form);
            form.submit()
        });
    };

   return{
       init : function(){

           $('#Newsubmenu').on('hidden.bs.modal', function (e) {
               $('.form-control').attr('data-toggle', '');
               $('.form-control').attr('data-placement', '');
               $('.form-control').attr('title', '');
               $('.form-control').tooltip('dispose');

               $('.form-control').removeClass('invalid');
               $('.form-control').val('');
           });

           handleDataTable();
           handleBarang();
           handleFormSubmit();
           handleAllBarang();
           handleExportExcel();
           console.log(MODUL_FN);
       }
   }
}();

$(document).ready(function(){
    Index.init();
});