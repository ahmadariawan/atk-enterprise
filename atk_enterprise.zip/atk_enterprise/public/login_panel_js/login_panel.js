var Index = function () {

    var handleFormSubmit = function () {

        var rules = {};
        var messages = {};

        rules["password"] = { required: true };
        messages["password"] = { required: "wajid di isi !" };

        rules["username"] = { required: true };
        messages["username"] = { required: "wajid di isi !" };

        $("#login-panel-form").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#login-panel-form").submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = new FormData(form[0]);

            if($(this).valid()){
                $.ajax({
                    url: ThisUrl + '/panel_login',
                    type: "post",
                    data: formData,
                    processData: false,
                    contentType: false,
                    enctype: 'multipart/form-data',
                    success: function (responses) {
                        obj = JSON.parse(responses);

                        if(obj.success){
                            setTimeout(function () {
                                window.location.href = ThisUrl;
                            }, 3000);
                        }else{

                            toastr.error(obj.message, 'Form Tidak Valid !');
                        }
                    }
                });
            }
        });

    };

    return{
        init : function(){
            handleFormSubmit();
        }
    }
}();

$(document).ready(function(){
    Index.init();
});