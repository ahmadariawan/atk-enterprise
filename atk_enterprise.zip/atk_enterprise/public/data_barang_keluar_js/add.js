var Index = function () {

    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var handleFormSubmit = function () {

        var rules = {};
        var messages = {};

        rules["barang_id"] = { required: true };
        messages["barang_id"] = { required: "wajid di isi !" };

        rules["stok_keluar"] = { required: true };
        messages["stok_keluar"] = { required: "wajid di isi !" };

        $("#add_barang_keluar").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#add_barang_keluar").submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = new FormData(form[0]);

            if($(this).valid()){
                $.ajax({
                    url: ThisUrl + '/add_barang_keluar',
                    type: "post",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (responses) {
                        obj = JSON.parse(responses);

                        if(obj.success){
                            $('#btn-submit').remove();
                            toastr.success('Data berhasil di simpan', 'Success');
                            setTimeout(function () {
                                window.location.href = ThisUrl + '/data_barang_keluar';
                            }, 3000);
                        }else{

                            toastr.error(obj.message, 'Form Tidak Valid !');
                        }
                    }
                });
            }
        });

    };

    var handleBarang = function(){
        $('#barang_id').select2({
            placeholder: 'Barang',
            theme: "bootstrap",
            allowClear: true
        });

        $('#barang_id').on('change',function(){
            var barang_id = $(this).val();

            $.ajax({
                url: ThisUrl + '/get_stok',
                type: "post",
                data: {
                    'barang_id' : barang_id,
                    '_token' : CSRF_TOKEN,
                },
                success: function (responses) {
                    obj = JSON.parse(responses);
                    $('#satuan_desc').val(obj.satuan);
                }
            });
        });
    };

    return{
        init : function(){
            $('#back-to-list').on('click',function () {
                window.location.href = ThisUrl + '/data_barang_keluar';
            });

            handleFormSubmit();
            handleBarang();
        }
    }
}();

$(document).ready(function(){
    Index.init();
});