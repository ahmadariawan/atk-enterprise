var Index = function () {

    var aSelected = [];
    var table;
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var handleDataTable = function(){
        $.fn.dataTable.ext.classes.sPageButton = 'btn btn-primary btn-sm mr-1';
        table = $('#data-jenis-barang').DataTable({
            "searching": true,
            "scrollX": true,
            "paging": true,
            "lengthMenu": [[5, 10, 25, 50, 100], [5, 10, 25, 50, 100]],
            "pagingType": "simple_numbers",
            "language": {
                "info": "Menampilkan _START_ - _END_ dari _TOTAL_ data",
                "infoEmpty": "Menampilkan 0 - 0 dari 0 data",
                "infoFiltered": "",
                "zeroRecords": "Data tidak di temukan",
                "loadingRecords": "Loading...",
                "processing": "Processing...",
            },
            "columnDefs": [
                { "searchable": false, "targets": [0, 1, 3] },
                { "orderable": false, "targets": [0, 1, 3] },
            ],
            "processing": true,
            "serverSide": true,
            "ajax": {
                "url": ThisUrl + "/get_list_jenis_barang",
                "type": "POST",
                "data" : {
                    "_token" : CSRF_TOKEN,
                }
            },
            "columns": [
                { "data": "cbox" },
                { "data": "rnum" },
                { "data": "name" },
                { "data": "action" }
            ],
            "rowCallback": function( row, data ) {
                $(row).addClass('text-center');
                // $(row).children().eq(0).attr('style','border-left: 1px solid #e3e6f0;');
                // $(row).children().eq(5).attr('style','border-right: 1px solid #e3e6f0;');
            },
            "dom": '<"toolbar">lfrtip',
            "drawCallback": function( settings ) {

                $('.data-jenis-barang-cbox').on('click', function () {
                    handleAddDeleteAselected($(this).val(), $(this).parents()[1]);
                });

                $('#btn-delete').attr('disabled','');
                aSelected.splice(0,aSelected.length);

            }
        });

        $("#sidebarToggle").on('click', function () {
            table.draw();
        });

        $("#data-jenis-barang_paginate").addClass("table-responsive");

        $('#data-jenis-barang_wrapper').attr('style','margin-top:10px;');


        $("div.toolbar").html(
            '<a href="javascript:;" id="btn-refresh" class="btn btn-secondary btn-sm mr-1 mb-3">Refresh</a>' +
            '<a href="javascript:;" id="btn-add" class="btn btn-success btn-sm mr-1 mb-3" data-toggle="modal" data-target="#Newsubmenu" style="visibility:hidden">Tambah Data</a>' +
            '<button type="button" id="btn-delete" class="btn btn-danger btn-sm mb-3" style="visibility:hidden">Hapus Data</button>'
            // '<button type="button" id="btn-export-excel" class="btn btn-success btn-sm mb-3" style="float: right">Export Excel</button>'
        );

        $("div #data-jenis-barang_filter").find(':input').addClass('form-control form-control-sm');

        $(".data-jenis-barang-tfoot-input-search").on('change',function(){
            var data_index = $(this).attr('data-index');
            table.columns(data_index).search( $(this).val() ).draw();
        });

        $('#btn-refresh').on('click', function(){
            window.location.reload();
        });

        $('#btn-delete').attr('disabled','');

        if($.inArray('add',MODULE_FN) !== -1){
            $('#btn-add').css('visibility','visible');
        }

        if($.inArray('delete',MODULE_FN) !== -1){
            $('#btn-delete').css('visibility','visible');
        }
    };

    var handleAddDeleteAselected = function (value, parentElement) {

        var check_value = $.inArray(value, aSelected);
        if(check_value !== -1){
            $(parentElement).removeClass('row-selected');
            aSelected.splice(check_value, 1);
        }else{
            $(parentElement).addClass('row-selected');
            aSelected.push(value);
        }

        handleBtnDisableEnable();
    };

    var handleBtnDisableEnable = function () {
        if(aSelected.length > 0){
            $('#btn-delete').removeAttr('disabled');
        }else{
            $('#btn-delete').attr('disabled','');
        }
    };

    var  handleRemoveData = function () {
        $('#btn-delete').on('click', function () {
            console.log(aSelected);

            $.ajax({
                url: ThisUrl + '/delete_jenis_barang',
                type: "post",
                data: {
                    'ids' : aSelected,
                    '_token' : CSRF_TOKEN,
                },
                success: function (responses) {
                    obj = JSON.parse(responses);

                    if(obj.success){
                         toastr.success('Data berhasil di hapus', 'Success');
                         setTimeout(function () {
                             window.location.reload();
                         }, 3000);
                    }else{

                        toastr.error('Data gagal di hapus', 'Error');
                    }
                }
             });

        });
    };

    var handleFormSubmit = function () {

        var rules = {};
        var messages = {};

        rules["name"] = { required: true };
        messages["name"] = { required: "wajid di isi !" };

        $("#add_jenis_barang").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#add_jenis_barang").submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = new FormData(form[0]);

            if($(this).valid()){
                $.ajax({
                   url: ThisUrl + '/add_jenis_barang',
                   type: "post",
                   data: formData,
                   processData: false,
                   contentType: false,
                   success: function (responses) {
                       obj = JSON.parse(responses);

                       if(obj.success){
                            $('#Newsubmenu').modal('hide');
                            toastr.success('Data berhasil di simpan', 'Success');
                            setTimeout(function () {
                                window.location.reload();
                            }, 3000);
                       }else{

                           toastr.error(obj.message, 'Form Tidak Valid !');
                       }
                   }
                });
            }
        });

    };

   return{
       init : function(){

           $('#Newsubmenu').on('hidden.bs.modal', function (e) {
               $('.form-control').attr('data-toggle', '');
               $('.form-control').attr('data-placement', '');
               $('.form-control').attr('title', '');
               $('.form-control').tooltip('dispose');

               $('.form-control').removeClass('invalid');
               $('.form-control').val('');
           });

           handleDataTable();
           handleFormSubmit();
           handleRemoveData();
           console.log(MODULE_FN);
       }
   }
}();

$(document).ready(function(){
    Index.init();
});