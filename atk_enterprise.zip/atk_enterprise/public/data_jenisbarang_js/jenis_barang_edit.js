var Index = function () {

    var handleFormSubmit = function () {

        var rules = {};
        var messages = {};

        rules["name"] = { required: true };
        messages["name"] = { required: "wajid di isi !" };

        $("#edit_jenis_barang").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#edit_jenis_barang").submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = new FormData(form[0]);
                formData.append('id_jenis_barang', id_jenis_barang);

            if($(this).valid()){
                $.ajax({
                    url: ThisUrl + '/edit_jenis_barang',
                    type: "post",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (responses) {
                        obj = JSON.parse(responses);

                        if(obj.success){
                            $('#btn-submit').remove();
                            toastr.success('Data berhasil di simpan', 'Success');
                            setTimeout(function () {
                                window.location.href = ThisUrl + '/jenis_barang';
                            }, 3000);
                        }else{

                            toastr.error(obj.message, 'Form Tidak Valid !');
                        }
                    }
                });
            }
        });

    };

    return{
        init : function(){
            $('#back-to-list').on('click',function () {
                window.location.href = ThisUrl + '/jenis_barang';
            });

            handleFormSubmit();
        }
    }
}();

$(document).ready(function(){
    Index.init();
});