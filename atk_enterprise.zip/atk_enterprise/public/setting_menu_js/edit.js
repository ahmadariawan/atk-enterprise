var Index = function () {
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

    var handleHakAkses = function(){
        $('.hak-akses').on('change', function(){
            var id = $(this).attr('data-id');
            var value = $('option:selected', this).val();

            $.ajax({
                url: ThisUrl + '/edit_setting_menu',
                type: "post",
                data: {
                    'id': id,
                    'is_akses': value,
                    'update_for': 'is_akses',
                    '_token' : CSRF_TOKEN,
                },
                success: function (responses) {
                    obj = JSON.parse(responses);

                    if(obj.success){
                         toastr.success('Data berhasil di update', 'Success');
                        //  setTimeout(function () {
                        //      window.location.reload();
                        //  }, 3000);
                    }else{

                        toastr.error('Data gagal di update', 'Error');
                    }
                }
            });
        });
    };
    
    var handleModuleFn = function(){
        $('.module_fn').tagsinput();
        $('.module_fn').on('change', function(){
            var id =  $(this).attr('data-id');
            var value = $(this).val();

            $.ajax({
                url: ThisUrl + '/edit_setting_menu',
                type: "post",
                data: {
                    'id': id,
                    'module_fn': value,
                    'update_for': 'module_fn',
                    '_token' : CSRF_TOKEN,
                },
                success: function (responses) {
                    obj = JSON.parse(responses);

                    if(obj.success){
                         toastr.success('Data berhasil di update', 'Success');
                        //  setTimeout(function () {
                        //      window.location.reload();
                        //  }, 3000);
                    }else{

                        toastr.error('Data gagal di update', 'Error');
                    }
                }
            });
        });
    };

    var handleTglDitutup = function(){
        $('.tgl_ditutup').tagsinput();
        $('.tgl_ditutup').on('change', function(){
            var id =  $(this).attr('data-id');
            var value = $(this).val();

            $.ajax({
                url: ThisUrl + '/edit_setting_menu',
                type: "post",
                data: {
                    'id': id,
                    'tgl_ditutup': value,
                    'update_for': 'tgl_ditutup',
                    '_token' : CSRF_TOKEN,
                },
                success: function (responses) {
                    obj = JSON.parse(responses);

                    if(obj.success){
                         toastr.success('Data berhasil di update', 'Success');
                        //  setTimeout(function () {
                        //      window.location.reload();
                        //  }, 3000);
                    }else{

                        toastr.error('Data gagal di update', 'Error');
                    }
                }
            });
        });
    };

   return{
       init : function(){

           $('#Newsubmenu').on('hidden.bs.modal', function (e) {
               $('.form-control').attr('data-toggle', '');
               $('.form-control').attr('data-placement', '');
               $('.form-control').attr('title', '');
               $('.form-control').tooltip('dispose');

               $('.form-control').removeClass('invalid');
               $('.form-control').val('');
           });

           $('#back-to-list').on('click',function () {
                window.location.href = ThisUrl + '/setting_menu';
           });

           handleHakAkses();
           handleModuleFn();
           handleTglDitutup();
       }
   }
}();

$(document).ready(function(){
    Index.init();
});