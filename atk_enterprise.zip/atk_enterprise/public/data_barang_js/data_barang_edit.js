var Index = function () {

    var handleFormSubmit = function () {

        var rules = {};
        var messages = {};

        rules["nomor_barang"] = { required: true };
        messages["nomor_barang"] = { required: "wajid di isi !" };

        rules["name"] = { required: true };
        messages["name"] = { required: "wajid di isi !" };

        rules["jenis_barang_id"] = { required: true };
        messages["jenis_barang_id"] = { required: "wajid di isi !" };

        rules["satuan_barang_id"] = { required: true };
        messages["satuan_barang_id"] = { required: "wajid di isi !" };

        rules["limit_stok"] = { required: true };
        messages["limit_stok"] = { required: "wajid di isi !" };

        $("#edit_barang").validate({
            onsubmit: false,
            rules: rules,
            messages: messages,
            ignore: "",
            errorClass: "invalid",
            validClass: "success",
            invalidHandler: function (event, validator) {
                toastr.error('Periksa Setiap Isian Yang Ada !', 'Form Tidak Valid !');
            },
            errorPlacement: function (error, element) {
                //console.log(error);
                $(element).attr('data-toggle', 'tooltip');
                $(element).attr('data-placement', 'top');
                $(element).attr('title', error[0].innerText);
                $(element).tooltip('show');
            },
            highlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).addClass(errorClass);
            },
            unhighlight: function (element, errorClass, validClass) {
                //console.log(element);
                $(element).attr('data-toggle', '');
                $(element).attr('data-placement', '');
                $(element).attr('title', '');
                $(element).tooltip('dispose');

                $(element).removeClass(errorClass)
            },
            success: function (label) {
                label.remove();
            },
        });

        $("#edit_barang").submit(function (e) {
            e.preventDefault();

            var form = $(this);
            var formData = new FormData(form[0]);
                formData.append('id_data_barang', id_data_barang);

            if($(this).valid()){
                $.ajax({
                    url: ThisUrl + '/edit_data_barang',
                    type: "post",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (responses) {
                        obj = JSON.parse(responses);

                        if(obj.success){
                            $('#btn-submit').remove();
                            toastr.success('Data berhasil di simpan', 'Success');
                            setTimeout(function () {
                                window.location.href = ThisUrl + '/data_barang';
                            }, 3000);
                        }else{

                            toastr.error(obj.message, 'Form Tidak Valid !');
                        }
                    }
                });
            }
        });

    };

    var handleJenisBarang = function(){
        $('#jenis_barang_id').select2({
            placeholder: 'Jenis Barang',
            theme: "bootstrap",
            allowClear: true
        });
    };

    var handleSatuanBarang = function(){
        $('#satuan_barang_id').select2({
            placeholder: 'Satuan Barang',
            theme: "bootstrap",
            allowClear: true
        });
    };

    return{
        init : function(){
            $('#back-to-list').on('click',function () {
                window.location.href = ThisUrl + '/data_barang';
            });

            handleFormSubmit();
            handleJenisBarang();
            handleSatuanBarang();
        }
    }
}();

$(document).ready(function(){
    Index.init();
});