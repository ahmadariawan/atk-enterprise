<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['authloginapp'])->group(function (){

    Route::get('/', function () {
        return view('global_template.layout_app');
    })->name('home_route');


    #DATA DOSEN ROUTE
    // Route::get('data_dosen', 'DosenController@show')->name('list_dosen');

    // Route::get('get_list_dosen', function (){
    //     echo "404 NOT FOUND";
    // })->name('get_list_dosen1');

    // Route::post('get_list_dosen', 'DosenController@get_list')->name('get_list_dosen');

    // Route::get('add_dosen', function (){
    //     echo "404 NOT FOUND";
    // })->name('add_dosen');

    // Route::post('add_dosen', 'DosenController@save_data');

    // Route::get('edit_dosen/{id}', 'DosenController@edit_data')->middleware('authmodulefunction')->name('edit_data_dosen');

    // Route::get('edit_dosen', function (){
    //     echo "404 NOT FOUND";
    // })->name('edit_data_dosen1');

    // Route::post('edit_dosen', 'DosenController@save_edit_data');
    #END DATA DOSEN ROUTEEEEEEEEEEEEEEEE

    #DEPARTEMEN ROUTE START
    Route::get('data_departemen', 'DepartemenController@show')->name('list_departemen');

    Route::get('get_list_departemen', function (){
        echo "404 NOT FOUND";
    })->name('get_list_departemen1');

    Route::post('get_list_departemen', 'DepartemenController@get_list')->name('get_list_departemen');

    Route::get('add_departemen', function (){
        echo "404 NOT FOUND";
    })->name('add_departemen');

    Route::post('add_departemen', 'DepartemenController@save_data');

    Route::post('delete_departemen', 'DepartemenController@delete_data');

    Route::get('edit_departemen/{id}', 'DepartemenController@edit_data')->name('edit_departemen');

    Route::get('edit_departemen', function (){
        echo "404 NOT FOUND";
    })->name('edit_departemen1');

    Route::post('edit_departemen', 'DepartemenController@save_edit_data');
    #DEPARTEMEN ROUTE END

    #JENIS BARANG ROUTE START
    Route::get('jenis_barang', 'JenisBarangController@show')->name('jenis_barang');
    Route::post('get_list_jenis_barang', 'JenisBarangController@get_list')->name('get_list_jenis_barang');
    Route::post('add_jenis_barang', 'JenisBarangController@save_data');
    Route::get('edit_jenis_barang/{id}', 'JenisBarangController@edit_data')->name('edit_jenis_barang');
    Route::post('edit_jenis_barang', 'JenisBarangController@save_edit_data');
    Route::post('delete_jenis_barang', 'JenisBarangController@delete_data');
    #JENIS BARANG ROUTE END

    #SATUAN BARANG ROUTE START
    Route::get('satuan_barang', 'SatuanBarangController@show')->name('satuan_barang');
    Route::post('get_list_satuan_barang', 'SatuanBarangController@get_list')->name('get_list_satuan_barang');
    Route::post('add_satuan_barang', 'SatuanBarangController@save_data');
    Route::get('edit_satuan_barang/{id}', 'SatuanBarangController@edit_data')->name('edit_satuan_barang');
    Route::post('edit_satuan_barang', 'SatuanBarangController@save_edit_data');
    Route::post('delete_satuan_barang', 'SatuanBarangController@delete_data');
    #SATUAN BARANG ROUTE END

    #DATA BARANG ROUTE START
    Route::get('data_barang', 'BarangController@show')->name('data_barang');
    Route::post('get_list_data_barang', 'BarangController@get_list')->name('get_list_data_barang');
    Route::get('add_data_barang', 'BarangController@add')->name('add_data_barang');
    Route::post('add_data_barang', 'BarangController@save_data_add');
    Route::get('edit_data_barang/{id}', 'BarangController@edit')->name('edit_data_barang');
    Route::post('edit_data_barang', 'BarangController@save_data_edit');
    Route::post('delete_data_barang', 'BarangController@delete_data');

    Route::get('data_barang_masuk', 'BarangController@show_barang_masuk')->name('data_barang_masuk');
    Route::post('get_list_barang_masuk', 'BarangController@get_list_barang_masuk')->name('get_list_barang_masuk');
    Route::get('add_barang_masuk', 'BarangController@add_barang_masuk')->name('add_barang_masuk');
    Route::post('get_stok', 'BarangController@get_stok');
    Route::post('add_barang_masuk', 'BarangController@save_barang_masuk_add');
    Route::get('edit_barang_masuk/{id}', 'BarangController@edit_barang_masuk')->name('edit_barang_masuk');
    Route::post('edit_barang_masuk', 'BarangController@save_barang_masuk_edit');
    #DATA BARANG ROUTE END

    #DATA BARANG KELUAR ROUTE START
    Route::get('data_barang_keluar', 'BarangKeluarController@show')->name('data_barang_keluar');
    Route::post('get_list_barang_keluar', 'BarangKeluarController@get_list')->name('get_list_barang_keluar');
    Route::get('add_barang_keluar', 'BarangKeluarController@add')->name('add_barang_keluar');
    Route::post('add_barang_keluar', 'BarangKeluarController@save_add');
    Route::get('edit_barang_keluar/{id}', 'BarangKeluarController@edit')->name('edit_barang_keluar');
    Route::post('edit_barang_keluar', 'BarangKeluarController@save_edit');
    Route::post('approval_barang_keluar', 'BarangKeluarController@approval');
    Route::post('delete_barang_keluar', 'BarangKeluarController@delete_data');
    #DATA BARANG KELUAR ROUTE END

    #SETTING MENU ROUTE START
    Route::get('setting_menu', 'SettingMenuController@show')->name('setting_menu');
    Route::post('get_list_menu', 'SettingMenuController@get_list');
    Route::get('edit_setting_menu/{id}', 'SettingMenuController@edit')->name('edit_setting_menu');
    Route::post('edit_setting_menu', 'SettingMenuController@save_edit');
    #SETTING MENU ROUTE END

    #GROUPS MENU ROUTE START
    Route::get('groups_list', 'GroupsController@show')->name('groups_list');
    Route::post('get_list_groups', 'GroupsController@get_list');
    Route::post('add_groups', 'GroupsController@save_data');
    Route::get('edit_groups/{id}', 'GroupsController@edit_data')->name('edit_groups');
    Route::post('edit_groups', 'GroupsController@save_edit_data');
    #GROUPS MENU ROUTE END

    #USERS MENU ROUTE START
    Route::get('users_list', 'UsersController@show')->name('users_list');
    Route::post('get_list_users', 'UsersController@get_list');
    Route::get('add_user', 'UsersController@add')->name('add_user');
    Route::post('add_user', 'UsersController@save_data');
    Route::get('edit_users/{id}', 'UsersController@edit')->name('edit_users');
    Route::post('edit_users', 'UsersController@save_edit_data');
    #USERS MENU ROUTE END

    #DATA LAPORAN ROUTE START
    Route::get('data_laporan', 'DataLaporanController@show')->name('data_laporan');
    Route::post('get_list_data_laporan', 'DataLaporanController@get_list');
    #DATA LAPORAN ROUTE END

    Route::get('logout', 'LoginPanelController@logout_request')->name('logout_route');

});

Route::get('panel_login', 'LoginPanelController@show')->middleware('authpanellogin')->name('panel_login_route');
Route::post('panel_login', 'LoginPanelController@login_request');

Route::post('data_laporan_export', 'DataLaporanController@export');