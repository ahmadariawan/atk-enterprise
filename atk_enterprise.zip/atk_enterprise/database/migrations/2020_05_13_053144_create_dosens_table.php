<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDosensTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dosens', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('nidn');
            $table->string('name',250);
            $table->string('email', 250);
            $table->text('foto_path');
            $table->string('cretated_by','250');
            $table->dateTime('created_datetime');
            $table->tinyInteger('is_deleted')->default(0);
            $table->string('deleted_by','250')->nullable(true);
            $table->dateTime('deleted_datetime')->nullable(true);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dosens');
    }
}
