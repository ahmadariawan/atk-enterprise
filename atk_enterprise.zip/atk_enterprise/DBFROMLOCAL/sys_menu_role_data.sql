-- --------------------------------------------------------
-- Host:                         192.168.10.10
-- Server version:               8.0.21-0ubuntu0.20.04.4 - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping data for table atk_db.sys_menu_role: ~36 rows (approximately)
/*!40000 ALTER TABLE `sys_menu_role` DISABLE KEYS */;
INSERT INTO `sys_menu_role` (`id`, `sys_menu_id`, `sys_group_child_id`, `is_akses`, `module_fuction`) VALUES
	(1, 1, 1, 1, '["add","delete","edit"]'),
	(2, 1, 2, 0, '[]'),
	(3, 2, 1, 1, '["add","edit","delete"]'),
	(4, 2, 2, 0, '[]'),
	(5, 3, 1, 1, '["add","edit","delete"]'),
	(6, 3, 2, 0, '[]'),
	(7, 4, 1, 1, '["add","edit","delete"]'),
	(8, 4, 2, 0, '[]'),
	(9, 5, 1, 1, '["add","edit","delete"]'),
	(10, 5, 2, 0, '[]'),
	(11, 6, 1, 1, '["edit","approval"]'),
	(12, 6, 2, 1, '["add","edit"]'),
	(13, 7, 1, 1, '[]'),
	(14, 7, 2, 0, '[]'),
	(15, 8, 1, 1, '[]'),
	(16, 8, 2, 1, '[]'),
	(17, 9, 1, 1, '[]'),
	(18, 9, 2, 0, '[]'),
	(19, 10, 1, 1, '["add","edit"]'),
	(20, 10, 2, 0, '[]'),
	(21, 1, 3, 0, '[]'),
	(22, 2, 3, 0, '[]'),
	(23, 3, 3, 0, '[]'),
	(24, 4, 3, 0, '[]'),
	(25, 5, 3, 0, '[]'),
	(26, 6, 3, 0, '[]'),
	(27, 7, 3, 0, '[]'),
	(28, 8, 3, 0, '[]'),
	(29, 9, 3, 0, '[]'),
	(30, 10, 3, 0, '[]'),
	(31, 11, 1, 1, '["edit","add"]'),
	(32, 11, 2, 0, '[]'),
	(33, 11, 3, 0, '[]'),
	(45, 12, 1, 1, '["add"]'),
	(46, 12, 2, 0, '[]'),
	(47, 12, 3, 0, '[]');
/*!40000 ALTER TABLE `sys_menu_role` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
