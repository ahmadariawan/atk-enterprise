-- --------------------------------------------------------
-- Host:                         192.168.10.10
-- Server version:               8.0.21-0ubuntu0.20.04.4 - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping data for table atk_db.sys_group_child: ~3 rows (approximately)
/*!40000 ALTER TABLE `sys_group_child` DISABLE KEYS */;
INSERT INTO `sys_group_child` (`id`, `name`, `desc`, `created_by`, `created_datetime`) VALUES
	(1, 'SUPER_ADMIN', 'superadmin', 'admin', '2021-10-10 00:56:33'),
	(2, 'DEPARTEMEN', 'departemen', 'admin', '2021-10-24 01:35:06'),
	(3, 'PIC', 'pic', 'admin', '2021-10-31 13:47:57');
/*!40000 ALTER TABLE `sys_group_child` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
