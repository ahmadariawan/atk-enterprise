-- --------------------------------------------------------
-- Host:                         192.168.10.10
-- Server version:               8.0.21-0ubuntu0.20.04.4 - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping data for table atk_db.sys_menu: ~13 rows (approximately)
/*!40000 ALTER TABLE `sys_menu` DISABLE KEYS */;
INSERT INTO `sys_menu` (`id`, `name`, `is_menu_parent`, `created_by`, `created_datetime`) VALUES
	(1, 'modul_departemen', 0, 'admin', '2021-10-24 12:20:19'),
	(2, 'modul_jenis_barang', 0, 'admin', '2021-10-24 12:20:40'),
	(3, 'modul_satuan_barang', 0, 'admin', '2021-10-24 12:21:01'),
	(4, 'modul_barang', 0, 'admin', '2021-10-24 12:21:26'),
	(5, 'modul_barang_masuk', 0, 'admin', '2021-10-24 12:21:48'),
	(6, 'modul_barang_keluar', 0, 'admin', '2021-10-24 12:22:03'),
	(7, 'modul_data_master', 1, 'admin', '2021-10-24 12:27:54'),
	(8, 'modul_data_transaksi', 1, 'admin', '2021-10-24 12:28:54'),
	(9, 'modul_application', 1, 'admin', '2021-10-31 02:21:17'),
	(10, 'modul_setting_menu', 0, 'admin', '2021-10-31 02:21:39'),
	(11, 'modul_groups', 0, 'admin', '2021-11-06 20:07:59'),
	(12, 'modul_users', 0, 'admin', '2021-11-13 21:39:15'),
	(13, 'modul_data_laporan', 0, 'admin', '2021-11-21 14:42:18');
/*!40000 ALTER TABLE `sys_menu` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
